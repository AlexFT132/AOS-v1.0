/* Additive UI enhancement: no shell bundle replacement, no network calls. */
(() => {
  'use strict';
  if (window.__alexSidebarV1) return;
  window.__alexSidebarV1 = true;
  const root = document.documentElement;
  const key = 'alexserver.sidebar.compact.v1';
  const desktop = matchMedia('(min-width: 768px)');
  let compact = false;
  try { compact = localStorage.getItem(key) === '1'; } catch (_) {}
  let scheduled = false;
  function apply() {
    root.classList.add('alex-sidebar-ready');
    root.classList.toggle('alex-sidebar-compact', compact && desktop.matches);
    const button = document.getElementById('alex-sidebar-toggle');
    if (button) {
      const label = compact ? 'Развернуть меню' : 'Свернуть меню';
      if (button.title !== label) button.title = label;
      if (button.getAttribute('aria-label') !== label) button.setAttribute('aria-label', label);
      if (button.getAttribute('aria-expanded') !== String(!compact)) button.setAttribute('aria-expanded', String(!compact));
    }
  }
  let motion = [];
  let resizeTimer;
  const ease = 'cubic-bezier(.22,1,.36,1)';
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');
  function setCompact(value) {
    const animated = desktop.matches && !reduceMotion.matches && root.classList.contains('alex-motion-enabled');
    const nav = document.getElementById('nav-system');
    const targets = nav ? Array.from(nav.querySelectorAll('a.pf-v6-c-nav__link, .alex-tools')) : [];
    const oldNav = nav?.getBoundingClientRect();
    const before = new Map(targets.map(el => [el, el.getBoundingClientRect()]));
    const main = document.querySelector('.page > .area-ct-content');
    const oldMain = main?.getBoundingClientRect();
    motion.forEach(a => a.cancel()); motion = [];
    clearTimeout(resizeTimer);
    compact = value;
    try { localStorage.setItem(key, value ? '1' : '0'); } catch (_) {}
    apply();
    // FLIP translations keep icons and the page's vertical position continuous
    // while the registered CSS length drives a real layout-width transition.
    if (animated && nav && oldNav) {
      const nowNav = nav.getBoundingClientRect();
      const dy = oldNav.top - nowNav.top;
      for (const el of targets) {
        const from = before.get(el), to = el.getBoundingClientRect();
        const x = (from.left-oldNav.left)-(to.left-nowNav.left);
        const y = (from.top-oldNav.top)-(to.top-nowNav.top);
        if (Math.abs(x)+Math.abs(y) > .5) motion.push(el.animate([
          {transform:`translate(${x}px, ${y}px)`}, {transform:'translate(0,0)'}
        ], {duration:440,easing:ease}));
      }
      if (Math.abs(dy) > .5) motion.push(nav.animate([
        {transform:`translateY(${dy}px)`}, {transform:'translateY(0)'}
      ], {duration:440,easing:ease}));
      if (!compact) {
        for (const el of document.querySelectorAll('#host-apps > .search, #host-apps .nav-group-heading, #hosts-sel')) {
          motion.push(el.animate([{opacity:0},{opacity:1}], {duration:220,delay:100,easing:'ease-out',fill:'backwards'}));
        }
      }
      if (main && oldMain) {
        const y = oldMain.top-main.getBoundingClientRect().top;
        if (Math.abs(y) > .5) motion.push(main.animate([
          {transform:`translateY(${y}px)`}, {transform:'translateY(0)'}
        ], {duration:440,easing:ease}));
      }
    }
    window.dispatchEvent(new Event('resize'));
    resizeTimer = setTimeout(() => window.dispatchEvent(new Event('resize')), animated ? 460 : 0);
  }
  function iconFor(link, label) {
    const text = (label + ' ' + (link.getAttribute('href') || '')).toLowerCase();
    const rules = [
      [/zapret|vpn|запрет/, 'shield'], [/monitor|metrics|монитор/, 'monitor'],
      [/terminal|терминал/, 'terminal'], [/explorer|navigator|files|файл/, 'folder'],
      [/storage|хранилищ|диски/, 'storage'], [/network|сеть/, 'network'],
      [/hwinfo|hardware|оборудован/, 'cpu'], [/logs|journal|журнал/, 'logs'],
      [/users|accounts|уч[её]тные/, 'users'], [/services|служб/, 'services'],
      [/update|обновлен/, 'updates'], [/apps|applications|приложен/, 'apps'],
      [/overview|обзор|system\/index/, 'overview'], [/ssh|ключ/, 'key']
    ];
    return rules.find(([re]) => re.test(text))?.[1] || 'box';
  }
  function sync() {
    scheduled = false;
    const nav = document.getElementById('nav-system');
    const apps = document.getElementById('host-apps');
    if (!nav || !apps) return;
    if (!document.getElementById('alex-sidebar-tools')) {
      const tools = document.createElement('div');
      tools.id = 'alex-sidebar-tools'; tools.className = 'alex-tools';
      tools.innerHTML = '<button type="button" id="alex-sidebar-toggle" class="alex-toggle" aria-controls="host-apps"><span class="alex-mark" aria-hidden="true">A</span><span class="alex-toggle-label">Меню</span><span class="alex-glyph alex-chevron" aria-hidden="true"></span></button><button type="button" class="alex-search-button" title="Поиск в меню" aria-label="Поиск в меню"><span class="alex-glyph alex-search" aria-hidden="true"></span></button>';
      nav.insertBefore(tools, apps);
      tools.querySelector('.alex-toggle').addEventListener('click', () => setCompact(!compact));
      tools.querySelector('.alex-search-button').addEventListener('click', () => {
        setCompact(false);
        setTimeout(() => apps.querySelector('input')?.focus(), desktop.matches && !reduceMotion.matches ? 460 : 0);
      });
    }
    apps.querySelectorAll('a.pf-v6-c-nav__link').forEach(link => {
      const label = (link.querySelector('.nav-item-name')?.textContent || link.textContent || '').trim();
      if (!label) return;
      const icon = iconFor(link, label);
      if (link.dataset.alexIcon !== icon) link.dataset.alexIcon = icon;
      if (link.title !== label) link.title = label;
    });
    apply();
  }
  function queue() { if (!scheduled) { scheduled = true; requestAnimationFrame(sync); } }
  function init() {
    // React may remount the menu on reconnect, search or host switch.
    new MutationObserver(queue).observe(document.getElementById('shell') || document.body,
      {childList:true, subtree:true, characterData:true});
    desktop.addEventListener('change', apply);
    sync();
    requestAnimationFrame(() => requestAnimationFrame(() => root.classList.add('alex-motion-enabled')));
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();
