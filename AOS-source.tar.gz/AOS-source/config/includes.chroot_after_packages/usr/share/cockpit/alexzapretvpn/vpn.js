(function () {
    "use strict";
    const API = "/usr/share/cockpit/alexzapretvpn/alexzapretvpn-api";
    let users = [], selectedUser = null, busy = false, lastEventSignature = "", lastCoreState = null;
    let refreshing = false, autoRefresh = true, lastUserSignature = "", lastApiError = "", appliedEngine = "zapret1";
    let strategyEngine = "", strategySignature = "", modalReturnFocus = null;

    const SPEED_STORE = "alexzapretvpn:speed:v1:" + location.pathname;
    const SPEED_PAUSE_MS = 10 * 60 * 1000;
    let speedClient = null, speedRecords = Object.create(null);
    const rateSamples = new Map(), liveRates = new Map();
    try {
        const stored = JSON.parse(localStorage.getItem(SPEED_STORE) || "{}");
        if (stored && typeof stored === "object" && !Array.isArray(stored)) speedRecords = stored;
    } catch (_) { /* Invalid/unavailable storage must not prevent the dashboard from loading. */ }
    function clientKey(u) { return JSON.stringify([String(u.name), String(u.address || "")]); }
    function validSpeedRecord(record) {
        return record && [record.down, record.up, record.ping, record.measuredAt].every(n => typeof n === "number" && Number.isFinite(n) && n >= 0)
            && record.down <= 100000 && record.up <= 100000 && record.ping <= 60000;
    }
    function storeSpeedRecord(key, record) {
        const next = {...speedRecords};
        if (record) next[key] = record; else delete next[key];
        try { localStorage.setItem(SPEED_STORE, JSON.stringify(next)); speedRecords = next; return true; }
        catch (_) { toast("Браузер не разрешил сохранить результат. Проверьте доступ к локальному хранилищу.", true); return false; }
    }
    function sampleRates(list) {
        const now = performance.now(), seen = new Set();
        list.forEach(u => {
            const key = clientKey(u), rx = Number(u.rx), tx = Number(u.tx), old = rateSamples.get(key);
            seen.add(key);
            const dt = old ? (now - old.time) / 1000 : 0;
            let value = {down:null, up:null};
            if (old && dt >= 0.5 && dt <= 10 && Number.isFinite(rx) && Number.isFinite(tx) && rx >= old.rx && tx >= old.tx) {
                // Server TX is toward the client (download); server RX is from the client (upload).
                value = {down:(tx - old.tx) * 8 / dt / 1e6, up:(rx - old.rx) * 8 / dt / 1e6};
            }
            rateSamples.set(key, {rx, tx, time:now}); liveRates.set(key, value);
        });
        for (const key of rateSamples.keys()) if (!seen.has(key)) {rateSamples.delete(key);liveRates.delete(key);}
    }
    function fmtRate(value) { return Number.isFinite(value) ? value.toLocaleString("ru-RU", {maximumFractionDigits:1, minimumFractionDigits:1}) : "—"; }
    function speedWait(record) { return Math.max(0, Math.ceil(((Number(record?.requestedAt) || 0) + SPEED_PAUSE_MS - Date.now()) / 1000)); }
    function waitLabel(seconds) { return Math.floor(seconds / 60) + ":" + String(seconds % 60).padStart(2,"0"); }
    function openSpeed(u) {
        speedClient = u;
        const record = speedRecords[clientKey(u)];
        document.getElementById("speedTitle").textContent = "Спидтест — " + u.name;
        document.getElementById("speedFormError").hidden = true;
        const valid = validSpeedRecord(record);
        document.getElementById("speedDown").value = valid ? record.down : "";
        document.getElementById("speedUp").value = valid ? record.up : "";
        document.getElementById("speedPing").value = valid ? record.ping : "";
        const date = new Date(valid ? record.measuredAt : Date.now());
        date.setMinutes(date.getMinutes() - date.getTimezoneOffset());
        document.getElementById("speedDate").value = date.toISOString().slice(0,16);
        document.getElementById("clearSpeed").disabled = !valid;
        updateSpeedCooldown();
        document.getElementById("speedDialog").showModal();
    }
    function updateSpeedCooldown() {
        if (!speedClient) return;
        const wait = speedWait(speedRecords[clientKey(speedClient)]);
        document.getElementById("speedCopyLink").disabled = wait > 0;
        document.getElementById("speedCooldown").textContent = wait ? "Повторная выдача ссылки через " + waitLabel(wait) : "После копирования ссылки — пауза 10 минут. Автоматического теста нет.";
    }
    function initSpeedControls() {
        const dialog = document.getElementById("speedDialog");
        document.getElementById("closeSpeed").addEventListener("click", () => dialog.close());
        dialog.addEventListener("click", event => { if (event.target === dialog) {const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom) dialog.close();} });
        dialog.addEventListener("close", () => { speedClient = null; document.getElementById("speedForm").reset();document.getElementById("speedFormError").hidden=true; });
        document.getElementById("speedCopyLink").addEventListener("click", () => {
            if (!speedClient || speedWait(speedRecords[clientKey(speedClient)])) return;
            const key = clientKey(speedClient), link = document.getElementById("speedLink");
            if (!navigator.clipboard?.writeText) { link.focus();link.select();toast("Скопируйте выделенную ссылку вручную. Тест должен открыть пользователь.");return; }
            navigator.clipboard.writeText(link.value).then(() => {
                if (!storeSpeedRecord(key, {...speedRecords[key], requestedAt:Date.now()})) return;
                updateSpeedCooldown(); lastUserSignature = ""; renderUsers({users});
                toast("Ссылка скопирована. Передайте её пользователю для теста на его устройстве.");
            }).catch(() => {link.focus();link.select();toast("Доступ к буферу обмена запрещён. Скопируйте выделенную ссылку вручную.", true);});
        });
        document.getElementById("speedForm").addEventListener("submit", event => {
            event.preventDefault(); if (!speedClient) return;
            const key = clientKey(speedClient), measuredAt = new Date(document.getElementById("speedDate").value).getTime();
            const record = {...speedRecords[key], down:Number(document.getElementById("speedDown").value), up:Number(document.getElementById("speedUp").value), ping:Number(document.getElementById("speedPing").value), measuredAt};
            if (!validSpeedRecord(record) || measuredAt > Date.now() + 60000) {
                const error = document.getElementById("speedFormError");error.textContent = "Проверьте значения и время замера. Время не должно быть в будущем.";error.hidden = false;return;
            }
            if (!storeSpeedRecord(key, record)) return;
            dialog.close(); setTimeout(() => {lastUserSignature = ""; renderUsers({users});}, 0); toast("Сообщённый результат сохранён в этом браузере.");
        });
        document.getElementById("clearSpeed").addEventListener("click", () => {
            if (!speedClient || !confirm("Удалить сохранённый результат этого клиента?")) return;
            const key=clientKey(speedClient), old=speedRecords[key];
            if (!storeSpeedRecord(key, old?.requestedAt ? {requestedAt:old.requestedAt} : null)) return;
            dialog.close();setTimeout(() => {lastUserSignature="";renderUsers({users});},0);toast("Результат удалён; пауза выдачи ссылки сохранена.");
        });
        setInterval(() => { if (dialog.open) updateSpeedCooldown(); }, 1000);
    }

    function showApiError(message, partial = false) {
        document.querySelector("#apiError strong").textContent = partial ? "Часть данных недоступна" : "Нет связи с сервером";
        document.getElementById("apiError").hidden = false;
        document.getElementById("apiErrorText").textContent = message;
    }
    function setQr(svg) {
        // SVG rendered as an image cannot execute scripts or access the document.
        if (!String(svg).includes("<svg")) throw new Error("Сервер не вернул QR-код");
        const img = document.createElement("img");
        img.alt = "QR-код подключения";
        img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
        document.getElementById("qrBox").replaceChildren(img);
    }
    function showModal() {
        const modal = document.getElementById("modal");
        modalReturnFocus = document.activeElement;
        modal.classList.remove("hidden");
        document.body.style.overflow = "hidden";
        document.querySelector(".page").inert = true;
        document.querySelector(".modal-head .icon-button").focus();
    }
    function switchView(name) {
        document.querySelectorAll(".view").forEach(v => v.hidden = v.id !== "view-" + name);
        document.querySelectorAll("[data-tab]").forEach(b => {
            b.classList.toggle("active", b.dataset.tab === name);
            if (b.dataset.tab === name) b.setAttribute("aria-current", "page");
            else b.removeAttribute("aria-current");
        });
    }

    function sh(args) {
        if (!window.cockpit || typeof window.cockpit.spawn !== "function") {
            return Promise.reject(new Error("Панель работает внутри Cockpit. Откройте AlexZapret VPN на сервере через Cockpit."));
        }
        return cockpit.spawn(["sudo", "-n", API, ...args], { err: "message" }).then(x => x.trim());
    }
    function fmtBytes(n) {
        n = Number(n); if (!Number.isFinite(n)) return "—";
        const u = ["B", "KiB", "MiB", "GiB", "TiB"]; let i = 0;
        while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
        return n.toFixed(i ? 1 : 0) + " " + u[i];
    }
    function fmtDate(epoch) { const n = Number(epoch); return n ? new Date(n * 1000).toLocaleString("ru-RU") : "никогда"; }
    function toast(message, bad = false) {
        const el = document.getElementById("toast"); el.textContent = message;
        el.className = "toast show" + (bad ? " bad" : ""); clearTimeout(toast._timer);
        toast._timer = setTimeout(() => el.className = "toast", 3600);
    }
    function setStatus(level, text) {
        const dot = document.getElementById("statusDot"), label = document.getElementById("statusText");
        dot.className = "dot " + (level === "fail" ? "bad" : level === "warn" ? "warn" : "");
        label.textContent = text; label.style.color = level === "fail" ? "var(--red)" : level === "warn" ? "var(--yellow)" : "var(--green)";
    }
    function parseJson(text) { try { return JSON.parse(text); } catch (e) { throw new Error(text || "Некорректный ответ API"); } }
    function escapeHtml(s) {
        return String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;" }[c]));
    }
    function escapeAttr(s) { return String(s ?? "").replace(/[^a-zA-Z0-9_.-]/g, ""); }

    function scrollLogToBottom(element) {
        if (!element) return;
        element.scrollTop = element.scrollHeight;
    }

    function renderUsers(data) {
        users = data.users || []; document.getElementById("userCount").textContent = users.length;
        const query = (document.getElementById("userSearch")?.value || "").trim().toLowerCase();
        const filtered = users.filter(u => (u.name + " " + (u.address || "")).toLowerCase().includes(query));
        document.getElementById("visibleUsers").textContent = query ? `Показано ${filtered.length} из ${users.length}` : `Всего: ${users.length} · С активностью: ${users.filter(u => u.online).length}`;
        const signature = JSON.stringify([filtered, query, filtered.map(u => [liveRates.get(clientKey(u)),speedRecords[clientKey(u)],Math.ceil(speedWait(speedRecords[clientKey(u)])/60)])]);
        if (signature === lastUserSignature || !document.getElementById("modal").classList.contains("hidden")) return;
        lastUserSignature = signature;
        const box = document.getElementById("users");
        const focused = document.activeElement;
        const focusAttr = box.contains(focused) ? ["data-speed","data-speed-result","data-qr","data-copy","data-delete"].find(attr => focused.hasAttribute(attr)) : null;
        const focusValue = focusAttr ? focused.getAttribute(focusAttr) : null;
        box.innerHTML = "";
        if (!filtered.length) {
            box.innerHTML = query ? '<div class="empty-state"><strong>Ничего не найдено</strong>Попробуйте другое имя или IP-адрес.</div>' : '<div class="empty-state"><strong>Пока нет пользователей</strong>Добавьте первого клиента, чтобы получить конфигурацию и QR-код.</div>';
            return;
        }
        filtered.forEach(u => {
            const row = document.createElement("div"); row.className = "user-row client-card";
            const state = u.online ? '<span class="online">● Есть активность</span>' : '<span class="offline">● Нет активности</span>';
            const rate=liveRates.get(clientKey(u)) || {down:null,up:null}, record=speedRecords[clientKey(u)], valid=validSpeedRecord(record), wait=speedWait(record);
            const result=valid ? `<div class="speed-numbers"><span><span class="metric-arrow">↓</span> <b>${fmtRate(record.down)}</b><small>Мбит/с</small></span><span><span class="metric-arrow">↑</span> <b>${fmtRate(record.up)}</b><small>Мбит/с</small></span><span class="ping-value">${fmtRate(record.ping)} мс</span></div><div class="speed-meta manual">${escapeHtml(new Date(record.measuredAt).toLocaleString("ru-RU"))} · вручную</div>` : '<div class="untested">Нет измерения</div><div class="speed-meta">Пользователь ещё не сообщил результат</div>';
            row.innerHTML = `<div class="client-identity"><div class="client-avatar" aria-hidden="true">${escapeHtml((u.name || "?").slice(0,1).toUpperCase())}</div><div><div class="user-name">${escapeHtml(u.name)}</div><div class="user-ip">${escapeHtml(u.address || "—")}</div><div class="client-state">${state}</div><div class="user-handshake">Handshake: ${u.handshake ? escapeHtml(fmtDate(u.handshake)) : "нет данных"}</div></div></div>
                <div class="live-speed"><div class="mobile-label">Трафик VPN сейчас</div><div class="speed-numbers"><span><span class="metric-arrow">↓</span> <b>${fmtRate(rate.down)}</b><small>Мбит/с</small></span><span><span class="metric-arrow">↑</span> <b>${fmtRate(rate.up)}</b><small>Мбит/с</small></span></div><div class="speed-meta">${rate.down === null ? "Ожидаем два свежих измерения" : "Счётчики WireGuard · не спидтест"}</div><div class="rate-note">Всего: ↓ ${fmtBytes(u.tx)} · ↑ ${fmtBytes(u.rx)}</div></div>
                <div class="speed-result"><div class="mobile-label">Последний спидтест</div>${result}<div class="button-row"><button class="speedtest-btn" data-speed="${escapeHtml(u.name)}" ${wait ? "disabled" : ""}>${wait ? "Ссылка через " + waitLabel(wait) : "↗ Ссылка на тест"}</button><button data-speed-result="${escapeHtml(u.name)}">Результат</button></div></div>
                <div class="user-actions client-actions"><button data-qr="${escapeHtml(u.name)}">QR</button><button data-copy="${escapeHtml(u.name)}">Конфиг</button><button class="delete-user-btn" data-delete="${escapeHtml(u.name)}" title="Удалить пользователя" aria-label="Удалить пользователя">×</button></div>`;
            box.appendChild(row);
        });
        box.querySelectorAll("[data-speed],[data-speed-result]").forEach(b => b.addEventListener("click", () => {
            const user = users.find(u => u.name === (b.dataset.speed || b.dataset.speedResult));if(user) openSpeed(user);
        }));
        box.querySelectorAll("[data-qr]").forEach(b => b.addEventListener("click", () => openQr(b.dataset.qr)));
        box.querySelectorAll("[data-copy]").forEach(b => b.addEventListener("click", () => copyConfig(b.dataset.copy)));
        box.querySelectorAll("[data-delete]").forEach(button => {
            button.addEventListener("click", () => {
                const name = button.dataset.delete;

                if (!confirm(`Удалить пользователя ${name}?\n\nБудут удалены его конфигурация и peer WireGuard. Отменить это действие можно будет только из резервной копии.`)) {
                    return;
                }

                if (busy) return;

                busy = true;
                button.disabled = true;

                sh(["delete-client", name])
                    .then(() => {
                        const deleted=users.find(u=>u.name===name);if(deleted) storeSpeedRecord(clientKey(deleted),null);
                        toast(`Пользователь ${name} удалён`);
                        refresh();
                    })
                    .catch(error => {
                        toast("Ошибка удаления: " + error.message, true);
                    })
                    .finally(() => {
                        busy = false;
                        refresh();
                    });
            });
        });
        if (focusAttr) {
            const replacement=[...box.querySelectorAll("["+focusAttr+"]")].find(el=>el.getAttribute(focusAttr)===focusValue);
            if (replacement && !replacement.disabled) replacement.focus({preventScroll:true});
        }
    }

    function renderMain(data) {
        const wg = data.wireguard || {}, zap = data.zapret || {};
        document.getElementById("port").textContent = wg.port || "51820";
        document.getElementById("iface").textContent = wg.interface || "wg0";
        document.getElementById("wgStatus").textContent = wg.active ? "Работает" : "Остановлен";
        document.getElementById("wgStatus").className = "big status-value " + (wg.active ? "ok" : "bad");
        document.getElementById("wgDetail").textContent = (wg.interface || "wg0") + " · " + (wg.peers ?? 0) + " клиентов";
        document.getElementById("zapretStatus").textContent = zap.active ? "Работает" : "Остановлен";
        document.getElementById("zapretStatus").className = "big status-value " + (zap.active ? "ok" : "bad");
        document.getElementById("zapretDetail").textContent = zap.detail || "—";

        appliedEngine = zap.engine || "zapret1";
        const engineSelect = document.getElementById("zapretEngine");

        if (engineSelect && zap.engine && !engineSelect.dataset.userChanging) {

            engineSelect.value = zap.engine;

        }
        document.getElementById("strategyShort").textContent = data.strategy?.name || "—";
        document.getElementById("totalRx").textContent = fmtBytes(data.totals?.rx || 0);
        document.getElementById("totalTx").textContent = fmtBytes(data.totals?.tx || 0);
        document.getElementById("lastHandshake").textContent = data.totals?.lastHandshake ? "Последнее рукопожатие: " + fmtDate(data.totals.lastHandshake) : "Последнее рукопожатие: —";
        const info = document.getElementById("vpnInfo");

        const activeEngine = zap.engine || "zapret1";

        const queueNumber = activeEngine === "zapret2" ? "300" : "200";

        const configFile = activeEngine === "zapret2"

            ? "/opt/zapret2/config"

            : "/etc/zapret-vpn/strategy.conf";


        info.innerHTML = [

            ["Интерфейс", wg.interface],

            ["Порт", wg.port],

            ["Сеть VPN", wg.network],

            ["Активный движок", activeEngine === "zapret2" ? "Zapret 2" : "Zapret 1"],

            ["NFQUEUE", queueNumber],

            ["Конфигурация", configFile],

            ["Zapret", zap.active ? "Работает" : "Остановлен"],

            ["Watchdog", data.watchdog || "—"]

        ].map(([k, v]) =>

            `<div class="k">${escapeHtml(k)}</div><div class="v">${escapeHtml(v ?? "—")}</div>`

        ).join("");

        const coreState = `${!!wg.active}:${!!zap.active}`;
        if (lastCoreState !== null && coreState !== lastCoreState) {
            toast(!wg.active ? "ПРЕДУПРЕЖДЕНИЕ: WireGuard остановлен" : !zap.active ? "ПРЕДУПРЕЖДЕНИЕ: Zapret остановлен" : "WireGuard и Zapret снова активны", !wg.active || !zap.active);
        }
        lastCoreState = coreState;
        const level = !wg.active || !zap.active ? "fail" : data.watchdog !== "active" ? "warn" : "ok";
        setStatus(level, level === "fail" ? "Требует внимания" : level === "warn" ? "Работает · Watchdog отключён" : "Службы работают");
    }


    function renderStrategy(data) {
        const select = document.getElementById("strategySelect");
        const engine = document.getElementById("zapretEngine").value;
        const changedEngine = strategyEngine !== engine;
        const old = changedEngine ? "" : select.value;
        const signature = JSON.stringify([engine, data.strategies || []]);
        if (signature !== strategySignature) {
            select.replaceChildren();
            (data.strategies || []).forEach(st => {
                const option = document.createElement("option");
                option.value = st.file; option.textContent = st.name;
                option.dataset.content = st.content || "";
                option.selected = !!st.active;
                select.appendChild(option);
            });
            if (old && [...select.options].some(o => o.value === old)) select.value = old;
            strategySignature = signature;
        }
        strategyEngine = engine;
        const current = (data.strategies || []).find(st => st.active);
        const selected = select.selectedOptions[0];
        document.getElementById("strategyOptions").textContent = selected?.dataset.content || data.current || "Пресеты не найдены.";
        document.getElementById("strategyShort").textContent = current?.name || (data.current?.trim() ? "Настроена" : "—");
        const applyButton = document.getElementById("applyStrategy");
        applyButton.disabled = engine !== "zapret1" || !select.options.length;
        applyButton.title = engine === "zapret1" ? "Применить пресет Zapret 1" : "Применение пресетов Zapret 2 пока не поддерживается";
    }

    function renderWireGuardPeers(dump, clientUsers = users) {
        const summary = document.getElementById("wgSummary");
        const box = document.getElementById("wgDump");

        if (!summary || !box) return;

        const lines = String(dump || "").split("\n");

        const getValue = (prefix, source = lines) => {
            const line = source.find(x => x.trim().startsWith(prefix));
            return line ? line.substring(line.indexOf(":") + 1).trim() : "";
        };

        const iface = getValue("interface");
        const publicKey = getValue("public key");
        const port = getValue("listening port");

        const sections = String(dump || "").split(/(?=^peer:\s)/m);

        const peers = sections
            .filter(section => /^peer:\s/m.test(section))
            .map(section => {
                const peerLines = section.split("\n");
                const value = prefix => getValue(prefix, peerLines);

                const key = value("peer");
                const endpoint = value("endpoint") || "Нет данных";
                const allowed = value("allowed ips") || "—";
                const address = allowed.split(",")[0].trim().split("/")[0];
                const handshake = value("latest handshake") || "Нет handshake";
                const transfer = value("transfer");

                const client = clientUsers.find(u =>
                    String(u.address || "").split("/")[0] === address
                );

                const rx = transfer.match(/([\d.]+\s+\w+)\s+received/i);
                const tx = transfer.match(/([\d.]+\s+\w+)\s+sent/i);

                let active = client
                    ? !!client.online
                    : false;

                if (!client) {
                    const seconds = handshake.match(/(\d+)\s+second/i);
                    const minutes = handshake.match(/(\d+)\s+minute/i);
                    const hours = handshake.match(/(\d+)\s+hour/i);
                    const days = handshake.match(/(\d+)\s+day/i);

                    const age =
                        Number(seconds?.[1] || 0) +
                        Number(minutes?.[1] || 0) * 60 +
                        Number(hours?.[1] || 0) * 3600 +
                        Number(days?.[1] || 0) * 86400;

                    active =
                        !/^(never|0)$/i.test(handshake) &&
                        !/нет handshake/i.test(handshake) &&
                        age <= 180;
                }

                return {
                    key,
                    endpoint,
                    allowed,
                    address,
                    handshake,
                    rx: rx?.[1] || "0 B",
                    tx: tx?.[1] || "0 B",
                    name: client?.name || address || "Неизвестный клиент",
                    active
                };
            });

        summary.innerHTML = `
            <div class="wg-summary-item">
                <div class="wg-summary-label">Интерфейс</div>
                <div class="wg-summary-value">${escapeHtml(iface || "wg0")}</div>
            </div>

            <div class="wg-summary-item">
                <div class="wg-summary-label">Порт прослушивания</div>
                <div class="wg-summary-value">${escapeHtml(port || "—")}</div>
            </div>

            <div class="wg-summary-item">
                <div class="wg-summary-label">Клиентов</div>
                <div class="wg-summary-value">${peers.length}</div>
            </div>

            <div class="wg-summary-item" style="grid-column: 1 / -1">
                <div class="wg-summary-label">Публичный ключ сервера</div>
                <div class="wg-summary-value">${escapeHtml(publicKey || "—")}</div>
            </div>
        `;

        if (!peers.length) {
            box.innerHTML = '<div class="muted">Подключённые клиенты WireGuard не найдены.</div>';
            return;
        }

        box.innerHTML = peers.map((peer, index) => `
            <div class="wg-peer">
                <div class="wg-peer-head">
                    <div class="wg-peer-title">
                        ${escapeHtml(peer.name)}
                    </div>

                    <div class="wg-peer-status ${peer.active ? "online" : "offline"}">
                        ${peer.active ? "● Активность недавно" : "● Нет активности"}
                    </div>
                </div>

                <div class="wg-peer-row">
                    <div class="wg-peer-label">Клиент</div>
                    <div class="wg-peer-value">${index + 1}</div>
                </div>

                <div class="wg-peer-row">
                    <div class="wg-peer-label">Адрес VPN</div>
                    <div class="wg-peer-value">${escapeHtml(peer.allowed)}</div>
                </div>

                <div class="wg-peer-row">
                    <div class="wg-peer-label">Внешний адрес</div>
                    <div class="wg-peer-value">${escapeHtml(peer.endpoint)}</div>
                </div>

                <div class="wg-peer-row">
                    <div class="wg-peer-label">Последний handshake</div>
                    <div class="wg-peer-value">${escapeHtml(peer.handshake)}</div>
                </div>

                <div class="wg-peer-row">
                    <div class="wg-peer-label">Публичный ключ клиента</div>
                    <div class="wg-peer-value">${escapeHtml(peer.key)}</div>
                </div>

                <div class="wg-peer-traffic">
                    <div>
                        <span>Получено (RX)</span>
                        <strong>${escapeHtml(peer.rx)}</strong>
                    </div>

                    <div>
                        <span>Отправлено (TX)</span>
                        <strong>${escapeHtml(peer.tx)}</strong>
                    </div>
                </div>
            </div>
        `).join("");

    }

    function refresh() {
        if (busy || refreshing) return;
        refreshing = true;
        const button = document.getElementById("refreshNow");
        button.disabled = true;
        const requestedEngine = document.getElementById("zapretEngine").value;
        Promise.allSettled([
            sh(["status"]), sh(["strategies", requestedEngine]), sh(["log"]), sh(["dump"])
        ]).then(([status, strategies, log, dump]) => {
            if (status.status !== "fulfilled") throw status.reason;
            const state = parseJson(status.value);
            sampleRates(state.users || []); renderMain(state); renderUsers(state);
            if (strategies.status === "fulfilled" && requestedEngine === document.getElementById("zapretEngine").value) renderStrategy(parseJson(strategies.value));
            // After an external engine change, fetch its presets on the next tick.
            if (log.status === "fulfilled") {
                const el = document.getElementById("vpnLog");
                const atEnd = el.scrollHeight - el.scrollTop - el.clientHeight < 40;
                if (el.textContent !== log.value) { el.textContent = log.value || "Журнал пуст."; if (atEnd) scrollLogToBottom(el); }
            }
            if (dump.status === "fulfilled") renderWireGuardPeers(dump.value, state.users || []);
            const failures = [strategies, log, dump].filter(r => r.status === "rejected");
            if (failures.length) showApiError("Состояние служб обновлено, но часть данных недоступна: " + failures.map(r => r.reason?.message || String(r.reason)).join("; "), true);
            else document.getElementById("apiError").hidden = true;
            lastApiError = "";
            document.getElementById("updated").textContent = new Date().toLocaleTimeString("ru-RU");
        }).catch(e => {
            setStatus("fail", "Нет связи"); showApiError(e.message + " Статусы ниже могут быть неактуальны.");
            if (lastApiError !== e.message) toast("Ошибка VPN API: " + e.message, true);
            lastApiError = e.message;
        }).finally(() => { refreshing = false; button.disabled = false; });
    }
    function openQr(name) {
        document.getElementById("configBox").hidden = false;

        const copyButton = document.getElementById("copyConfig");
        if (copyButton) copyButton.hidden = false;
        selectedUser = name; busy = true;
        Promise.all([sh(["qr", name]), sh(["config", name])]).then(([svg, config]) => {
            document.getElementById("modalTitle").textContent = "QR — " + name;
            document.getElementById("modalSubtitle").textContent = "Отсканируйте код приложением WireGuard";
            setQr(svg); document.getElementById("configBox").textContent = config;
            showModal();
        }).catch(e => toast("Не удалось получить QR: " + e.message, true)).finally(() => busy = false);
    }
    function copyConfig(name) {
        sh(["config", name]).then(config => navigator.clipboard.writeText(config).then(() => toast("Конфигурация " + name + " скопирована"), () => toast("Браузер запретил доступ к буферу обмена", true))).catch(e => toast(e.message, true));
    }
    function closeModal() {
        document.getElementById("configBox").hidden = false;

        const copyButton = document.getElementById("copyConfig");
        if (copyButton) copyButton.hidden = false;
        document.getElementById("modal").classList.add("hidden"); document.getElementById("qrBox").innerHTML = "—";
        document.getElementById("configBox").textContent = ""; selectedUser = null;
        document.body.style.overflow = "";
        document.querySelector(".page").inert = false;
        if (modalReturnFocus?.isConnected) modalReturnFocus.focus();
    }
    function action(args, success) {
        if (busy) return; busy = true; toast("Выполняется: " + success + "…");
        sh(args).then(() => {
            toast(success + " — готово");
            if (args[0] === "engine") delete document.getElementById("zapretEngine").dataset.userChanging;
        }).catch(e => toast("Ошибка: " + e.message, true))
            .finally(() => { busy = false; refresh(); refreshTgws(); });
    }

    function renderChecks(targetId, items) {
        const box = document.getElementById(targetId); box.innerHTML = "";
        (items || []).forEach(item => {
            const state = item.status === "ok" ? "ok" : item.status === "warn" ? "warn" : "fail";
            const label = state === "ok" ? "OK" : state === "warn" ? "ВНИМАНИЕ" : "ОШИБКА";
            const div = document.createElement("div"); div.className = "check-item";
            div.innerHTML = `<div class="check-head"><span>${escapeHtml(item.name)}</span><span class="state-pill ${state}">${label}</span></div><div class="check-detail">${escapeHtml(item.detail || "—")}</div>`;
            box.appendChild(div);
        });
    }
    function runDiagnostics() {
        const btn = document.getElementById("runDiagnostics"); btn.disabled = true; btn.textContent = "Проверка…";
        sh(["diagnose"]).then(out => {
            const data = parseJson(out), items = data.items || [];
            renderChecks("diagnosticsResults", items);
            const fail = items.filter(x => x.status === "fail").length, warn = items.filter(x => x.status === "warn").length;
            document.getElementById("diagnosticsSummary").textContent = `${items.length} проверок: ${fail} ошибок, ${warn} предупреждений.`;
            toast(fail ? `Диагностика завершена: ошибок ${fail}` : warn ? `Диагностика завершена с предупреждениями: ${warn}` : "Диагностика пройдена");
        }).catch(e => toast("Ошибка диагностики: " + e.message, true)).finally(() => { btn.disabled = false; btn.textContent = "Запустить диагностику"; });
    }
    function refreshEvents() {
        sh(["events"]).then(text => {
            const out = text || "За последнее время подходящих событий не найдено.";
            const eventLog = document.getElementById("eventLog");
            eventLog.textContent = out;
            scrollLogToBottom(eventLog);
            const lines = out.split("\n").filter(x => /failed|failure|error|timeout|timed out|refused|unreachable|duckdns.*(fail|error)|result=exit-code/i.test(x));
            document.getElementById("eventSummary").textContent = lines.length ? `Найдено строк с признаками ошибок: ${lines.length}. Проверьте контекст ниже.` : "В выбранных журналах явных ошибок не обнаружено.";
            const sig = lines.slice(-4).join("\n");
            if (lastEventSignature && sig && sig !== lastEventSignature) toast("Обнаружено новое событие с признаками ошибки", true);
            lastEventSignature = sig;
        }).catch(e => { document.getElementById("eventSummary").textContent = "Не удалось загрузить события: " + e.message; });
    }

    function refreshTgws() {
        sh(["tgws", "status"]).then(out => {
            const s = parseJson(out);
            const badge = document.getElementById("tgBadge");

            badge.className = "state-pill " +
                (s.active && s.listening ? "ok" : s.active ? "warn" : "fail");
            badge.textContent = s.active && s.listening
                ? "Работает"
                : s.active ? "Порт не слушается" : "Остановлен";

            document.getElementById("tgInfo").innerHTML = [
                ["Состояние службы", s.state],
                ["PID", s.pid],
                ["Порт", s.listener]
            ].map(([k, v]) =>
                `<div class="k">${escapeHtml(k)}</div><div class="v">${escapeHtml(v || "—")}</div>`
            ).join("");

            const linkElement = document.getElementById("tgProxyLink");
            if (linkElement) {
                const link = s.proxyLink || "";
                linkElement.dataset.link = link;
                linkElement.textContent = link
                    ? "Ссылка готова — секрет скрыт"
                    : "Ссылка недоступна: проверь TG_SECRET";
            }
        }).catch(e => {
            document.getElementById("tgBadge").className = "state-pill fail";
            document.getElementById("tgBadge").textContent = "Ошибка проверки";
            document.getElementById("tgInfo").textContent = e.message;
        });
    }
    function copyTgProxyLink() {
    const linkElement = document.getElementById("tgProxyLink");
    const link = linkElement?.dataset?.link || "";

    if (!link || !/^tg:\/\/proxy\?/.test(link)) {
        toast("Ссылка прокси ещё не загружена", true);
        return;
    }

    navigator.clipboard.writeText(link)
        .then(() => toast("Ссылка Telegram-прокси скопирована"))
        .catch(() => toast("Не удалось скопировать ссылку", true));

    }
    function openTgProxyQr() {
        const linkElement = document.getElementById("tgProxyLink");
        const link = linkElement?.dataset?.link || "";

        if (!/^tg:\/\/proxy\?/.test(link)) {
            toast("Ссылка Telegram-прокси ещё не загружена", true);
            return;
        }

        const button = document.getElementById("tgShowQr");
        if (button) button.disabled = true;

        sh(["tgws", "qr"])
            .then(svg => {
                if (!svg || !svg.includes("<svg")) {
                    throw new Error("Сервер не вернул QR-код");
                }

                selectedUser = null;

                document.getElementById("modalTitle").textContent =
                    "QR-код Telegram-прокси";

                document.getElementById("modalSubtitle").textContent =
                    "Отсканируйте код камерой или приложением Telegram";

                setQr(svg);
                document.getElementById("configBox").textContent = "";
                document.getElementById("configBox").hidden = true;

                const copyButton = document.getElementById("copyConfig");
                if (copyButton) copyButton.hidden = true;

                showModal();
            })
            .catch(error => {
                toast("Не удалось создать QR-код: " + error.message, true);
            })
            .finally(() => {
                if (button) button.disabled = false;
            });
    }

    function tgAction(actionName, label) {
        if (actionName !== "status" && !confirm(`${label} TgWsProxy?`)) return;
        sh(["tgws", actionName]).then(() => { toast(`${label}: команда выполнена`); refreshTgws(); refreshTgLog(); })
            .catch(e => toast(`${label}: ${e.message}`, true));
    }

    function refreshTgLog() {
        const log = document.getElementById("tgLog");

        sh(["tgws", "log"])
            .then(out => {
                log.textContent = out || "Лог пуст.";
                scrollLogToBottom(log);
            })
            .catch(e => {
                log.textContent = e.message;
                scrollLogToBottom(log);
            });
    }
    

    function diagnoseTgws() {
        const box = document.getElementById("tgDiagResults");
        box.textContent = "Проверка соединения…";
        sh(["tgws", "diagnose"])
            .then(out => renderChecks("tgDiagResults", parseJson(out).items || []))
            .catch(e => {
                box.textContent = "Ошибка диагностики: " + e.message;
            });
    }

    document.addEventListener("DOMContentLoaded", () => {
        initSpeedControls();
        document.querySelectorAll("[data-tab]").forEach(button => button.addEventListener("click", () => switchView(button.dataset.tab)));
        document.getElementById("userSearch").addEventListener("input", () => { lastUserSignature = ""; renderUsers({users}); });
        document.getElementById("pauseRefresh").addEventListener("click", event => {
            autoRefresh = !autoRefresh;
            event.currentTarget.setAttribute("aria-pressed", String(!autoRefresh));
            event.currentTarget.textContent = autoRefresh ? "Автообновление · 2 с" : "Обновление на паузе";
            if (autoRefresh) { refresh(); refreshTgws(); refreshEvents(); }
        });
        document.getElementById("retryConnection").addEventListener("click", () => { refresh(); refreshTgws(); refreshEvents(); refreshTgLog(); });
        document.getElementById("downloadConfig").addEventListener("click", () => {
            if (!selectedUser) return;
            const config = document.getElementById("configBox").textContent;
            if (!config) return;
            const url = URL.createObjectURL(new Blob([config], {type:"text/plain;charset=utf-8"}));
            const a = document.createElement("a"); a.href = url; a.download = selectedUser + ".conf"; a.click();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
        });
        document.addEventListener("keydown", event => {
            const modal = document.getElementById("modal");
            if (modal.classList.contains("hidden") || document.getElementById("speedDialog").open) return;
            if (event.key === "Escape") { event.preventDefault(); closeModal(); }
            if (event.key === "Tab") {
                const controls = [...modal.querySelectorAll("button:not(:disabled)")].filter(el => !el.hidden && el.offsetParent !== null);
                const first = controls[0], last = controls[controls.length - 1];
                if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
                else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
            }
        });
        new MutationObserver(() => {
            document.getElementById("downloadConfig").hidden = !selectedUser || document.getElementById("modal").classList.contains("hidden");
        }).observe(document.getElementById("modal"), {attributes:true, attributeFilter:["class"]});


        const excludeInput = document.getElementById("excludeDomains");
        const excludeButton = document.getElementById("saveExcludeDomains");
        const tgQrButton = document.getElementById("tgShowQr");
        if (tgQrButton) {
            tgQrButton.addEventListener("click", openTgProxyQr);
        }

        function loadExcludeDomains() {
            sh(["exclude-domains", "get"])
                .then(value => {
                    excludeInput.value = value;
                })
                .catch(e => toast("Не удалось загрузить исключения: " + e.message, true));
        }

        excludeButton.addEventListener("click", () => {
            const value = excludeInput.value.trim();

            if (!confirm(
                "Сохранить список исключений и перезапустить Zapret, если он запущен?"
            )) {
                return;
            }

            excludeButton.disabled = true;
            excludeButton.textContent = "Сохранение…";

            sh(["exclude-domains", "set", value])
                .then(() => {
                    toast("Исключения сохранены. Zapret проверен.");
                    refresh();
                })
                .catch(e => {
                    toast("Ошибка сохранения исключений: " + e.message, true);
                })
                .finally(() => {
                    excludeButton.disabled = false;
                    excludeButton.textContent = "Сохранить исключения";
                });
        });

        if (window.cockpit?.spawn) loadExcludeDomains();

        document.getElementById("applyEngine").addEventListener("click", () => {

    const target = document.getElementById("zapretEngine").value;

    const label = target === "zapret2" ? "Zapret2" : "Zapret 1";

    if (confirm("Переключить движок на " + label + "? Текущий движок будет остановлен.")) {

        action(["engine", "set", target], "Выбран " + label);

    }

});

document.getElementById("restartVpn").addEventListener("click", () => {

    const label = appliedEngine === "zapret2" ? "Zapret 2" : "Zapret 1";

    if (confirm("Перезапустить активный движок " + label + "?")) action(["restart"], label + " перезапущен");

});

        document.getElementById("restartWg").addEventListener("click", () => { if (confirm("Перезапустить WireGuard wg0?")) action(["restart-wg"], "WireGuard перезапущен"); });
        document.getElementById("addUser").addEventListener("click", () => {

            const button = document.getElementById("addUser");

            const input = prompt("Имя нового WireGuard-клиента (латиница, цифры, ., _, -):");

            if (input === null) return;



            const name = input.trim();

            if (!/^[A-Za-z0-9_.-]{1,32}$/.test(name) || name === "." || name === "..") {

                toast("Недопустимое имя. Используй 1–32 символа: латиницу, цифры, ., _, -", true);

                return;

            }

            if (busy) return;



            busy = true;

            button.disabled = true;

            button.textContent = "Создание…";



            sh(["create-client", name])

                .then(() => Promise.all([sh(["qr", name]), sh(["config", name])]))

                .then(([svg, config]) => {

                    selectedUser = name;
                    document.getElementById("configBox").hidden = false;
                    document.getElementById("copyConfig").hidden = false;

                    document.getElementById("modalTitle").textContent = "QR — " + name;

                    document.getElementById("modalSubtitle").textContent =

                        "Отсканируйте код приложением WireGuard";

                    setQr(svg);

                    document.getElementById("configBox").textContent = config;

                    showModal();

                    toast("Клиент " + name + " создан");

                })

                .catch(e => toast("Не удалось создать клиента: " + e.message, true))

                .finally(() => {

                    busy = false;

                    button.disabled = false;

                    button.textContent = "+ Пользователь";

                    refresh();

                });

        });


        document.getElementById("refreshPeers").addEventListener("click", () => {
            Promise.all([sh(["dump"]), sh(["status"])])
                .then(([dump, status]) => {
                    renderWireGuardPeers(dump, parseJson(status).users || []);
                    toast("Данные WireGuard обновлены");
                })
                .catch(e => toast("Ошибка WireGuard: " + e.message, true));
        });

        document.getElementById("refreshNow").addEventListener("click", refresh);
        document.getElementById("applyStrategy").addEventListener("click", () => {
            if (document.getElementById("zapretEngine").value !== "zapret1") {

    toast("Стратегии доступны только для Zapret 1", true);

    return;

}

            const file = document.getElementById("strategySelect").value; if (!file) return;
            if (confirm("Применить стратегию " + file + " и перезапустить zapret-vpn?")) action(["apply-strategy", file], "Стратегия применена");
        });
        document.getElementById("closeModal").addEventListener("click", closeModal);
        document.querySelectorAll("[data-close-modal]").forEach(e => e.addEventListener("click", closeModal));
        document.getElementById("copyConfig").addEventListener("click", () => { if (selectedUser) copyConfig(selectedUser); });
        document.getElementById("zapretEngine").addEventListener("change", () => {

            const select = document.getElementById("zapretEngine");

            select.dataset.userChanging = "1";

            refresh();

        });



        document.getElementById("strategySelect").addEventListener("change", () => {
            const opt = document.getElementById("strategySelect").selectedOptions[0];
            document.getElementById("strategyOptions").textContent = opt?.dataset?.content || "Выбранная стратегия";
        });
        document.getElementById("runDiagnostics").addEventListener("click", runDiagnostics);
        document.getElementById("refreshEvents").addEventListener("click", refreshEvents);
        document.getElementById("tgStart").addEventListener("click", () => tgAction("start", "Запустить"));
        document.getElementById("tgStop").addEventListener("click", () => tgAction("stop", "Остановить"));
        document.getElementById("tgRestart").addEventListener("click", () => tgAction("restart", "Перезапустить"));
        document.getElementById("tgDiagnose").addEventListener("click", diagnoseTgws);
        document.getElementById("tgRefreshLog").addEventListener("click", refreshTgLog);

        const tgCopyButton = document.getElementById("tgCopyLink");
        if (tgCopyButton) {
        tgCopyButton.addEventListener("click", copyTgProxyLink);
        }

        if (!window.cockpit || typeof window.cockpit.spawn !== "function") {
            setStatus("warn", "Открыто вне Cockpit");
            showApiError("Для реальных данных откройте панель на сервере через Cockpit. Локальная HTML-страница не подключается к VPN API.");
            document.querySelectorAll(".view button, .view select, .view textarea").forEach(el => el.disabled = true);
            document.getElementById("users").innerHTML = '<div class="empty-state"><strong>Данные сервера недоступны</strong>Откройте панель через Cockpit.</div>';
            document.getElementById("visibleUsers").textContent = "Нет данных";
            return;
        }
        refresh(); refreshEvents(); refreshTgws(); refreshTgLog();
        setInterval(() => { if (autoRefresh && !document.hidden) refresh(); }, 2000);
        setInterval(() => { if (autoRefresh && !document.hidden) refreshTgws(); }, 10000);
        setInterval(() => { if (autoRefresh && !document.hidden) refreshEvents(); }, 30000);
    });
})();
