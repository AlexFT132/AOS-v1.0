(function () {
  "use strict";

  const INTERVAL = 2000;
  const MAX = 60;
  const API = "/usr/local/bin/fan-control-api.sh";
  const history = { cpu: [], ram: [], rx: [], tx: [] };
  const $ = (id) => document.getElementById(id);
  let lastCpu = null,
    lastNet = null,
    timer = null,
    updating = false;
  let staticInfo = null,
    stopped = false,
    resizeFrame = null;
  let fanBusy = false,
    confirmedMode = "unknown",
    confirmedSpeed = 50;

  function text(id, value) {
    const el = $(id);
    if (el) el.textContent = value;
  }
  function pct(value) {
    return Number.isFinite(value) ? Math.max(0, Math.min(100, value)) : 0;
  }
  function push(key, value) {
    if (!Number.isFinite(value)) return;
    history[key].push(value);
    if (history[key].length > MAX) history[key].shift();
  }
  function fmtBytes(value) {
    if (!Number.isFinite(value) || value < 0) return "—";
    const units = ["B", "KiB", "MiB", "GiB", "TiB"];
    let i = 0;
    while (value >= 1024 && i < units.length - 1) {
      value /= 1024;
      i++;
    }
    return value.toFixed(i ? 1 : 0) + " " + units[i];
  }
  function spawn(args, options = {}, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      let process,
        finished = false;
      const finish = (fn, value) => {
        if (finished) return;
        finished = true;
        clearTimeout(timeout);
        fn(value);
      };
      const timeout = setTimeout(() => {
        finish(reject, new Error("Сервер не ответил вовремя."));
        if (process && typeof process.close === "function")
          process.close("timeout");
      }, timeoutMs);
      try {
        process = cockpit.spawn(args, options);
        Promise.resolve(process).then(
          (value) => finish(resolve, String(value).trim()),
          (error) => finish(reject, error),
        );
      } catch (error) {
        finish(reject, error);
      }
    });
  }
  const sh = (command) =>
    spawn(["bash", "-lc", "export LC_ALL=C; " + command], { err: "message" });

  function connection(state, message = "") {
    text("statusText", state);
    const dot = $("statusDot");
    dot.className =
      "dot" +
      (state === "ONLINE"
        ? ""
        : state === "CONNECTING"
          ? " pending"
          : " error");
    $("statusText").style.color =
      state === "ONLINE"
        ? "#72d572"
        : state === "CONNECTING"
          ? "#eac26b"
          : "#ff858b";
    const box = $("connectionMessage");
    box.hidden = !message;
    box.textContent = message;
  }

  function gauge(value) {
    const el = $("cpuGauge");
    el.style.strokeDashoffset = String(298 * (1 - pct(value) / 100));
    const color = value < 50 ? "#49e68b" : value < 80 ? "#ffd447" : "#ff4d5a";
    el.style.stroke = color;
    el.style.filter = "drop-shadow(0 0 8px " + color + "80)";
  }

  function draw(id, series, ceiling, format) {
    const canvas = $(id),
      width = canvas.clientWidth,
      height = canvas.clientHeight;
    if (!width || !height) return;
    const ratio = Math.min(3, window.devicePixelRatio || 1);
    canvas.width = Math.round(width * ratio);
    canvas.height = Math.round(height * ratio);
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.scale(ratio, ratio);
    ctx.strokeStyle = "rgba(255,255,255,.10)";
    ctx.lineWidth = 1;
    for (let i = 1; i < 4; i++) {
      const y = 24 + (i * (height - 32)) / 4;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
    const max = Math.max(1, ceiling);
    const descriptions = [];
    series.forEach((item) => {
      if (!item.data.length) return;
      ctx.strokeStyle = item.color;
      ctx.lineWidth = 2;
      ctx.setLineDash(item.dashed ? [5, 4] : []);
      ctx.beginPath();
      item.data.forEach((value, index) => {
        const x = 4 + (index * (width - 8)) / (MAX - 1);
        const y =
          height -
          8 -
          (Math.max(0, Math.min(max, value)) / max) * (height - 36);
        if (index) ctx.lineTo(x, y);
        else ctx.moveTo(x, y);
      });
      ctx.stroke();
      // A visible dot also represents the first collected sample.
      if (item.data.length === 1) {
        const y =
          height -
          8 -
          (Math.max(0, Math.min(max, item.data[0])) / max) * (height - 36);
        ctx.beginPath();
        ctx.arc(4, y, 2, 0, Math.PI * 2);
        ctx.fillStyle = item.color;
        ctx.fill();
      }
      descriptions.push(item.label + format(item.data[item.data.length - 1]));
    });
    ctx.setLineDash([]);
    ctx.font = "12px system-ui";
    ctx.fillStyle = "#bdc9d3";
    ctx.fillText(
      descriptions.length ? descriptions.join("   ") : "Сбор данных…",
      4,
      15,
      width - 8,
    );
  }
  function renderCharts() {
    const green = "#6ee7a0";
    draw(
      "cpuChart",
      [{ data: history.cpu, color: green, label: "" }],
      100,
      (v) => v.toFixed(1) + "%",
    );
    draw(
      "ramChart",
      [{ data: history.ram, color: green, label: "" }],
      100,
      (v) => v.toFixed(1) + "%",
    );
    const max = Math.max(1, ...history.rx, ...history.tx) * 1.2;
    draw(
      "netChart",
      [
        { data: history.rx, color: green, label: "↓ " },
        { data: history.tx, color: "#7acaff", label: "↑ ", dashed: true },
      ],
      max,
      (v) => fmtBytes(v) + "/s",
    );
  }

  function row(container, name, value, className, detail) {
    const el = document.createElement("div");
    el.className = className;
    const label = document.createElement("span");
    label.textContent = name;
    if (detail) {
      label.appendChild(document.createElement("br"));
      const small = document.createElement("span");
      small.className = "muted";
      small.textContent = detail;
      label.appendChild(small);
    }
    const result = document.createElement("span");
    result.className = "value";
    result.textContent = value;
    el.append(label, result);
    container.appendChild(el);
    return result;
  }
  function empty(container, message) {
    const el = document.createElement("div");
    el.className = "muted";
    el.textContent = message;
    container.appendChild(el);
  }
  function sensors(output) {
    const temperatures = [],
      fans = [],
      powers = [];
    for (const line of (output || "").split("\n")) {
      // Some sensor builds/locales return an ASCII C or a non-UTF-8 degree byte.
      let match = line.match(
        /^\s*([^:]+):\s*\+?(-?\d+(?:[.,]\d+)?)\s*(?:Â?°|º|\uFFFD)?\s*C\b/,
      );
      if (match)
        temperatures.push({
          name: match[1].trim(),
          value: Number(match[2].replace(",", ".")),
        });
      match = line.match(/^\s*([^:]+):\s*(\d+)\s*RPM/i);
      if (match) fans.push({ name: match[1].trim(), value: Number(match[2]) });
      match = line.match(/^\s*([^:]+):\s*([\d.]+)\s*W\b/);
      if (match && Number.isFinite(Number(match[2])))
        powers.push(Number(match[2]));
    }
    const box = $("sensors");
    box.replaceChildren();
    for (const item of temperatures) {
      const value = row(
        box,
        item.name,
        item.value.toFixed(1) + " °C",
        "sensor-row",
      );
      if (item.value >= 85) value.classList.add("bad");
      else if (item.value >= 70) value.classList.add("warn");
    }
    for (const item of fans)
      row(box, item.name, item.value.toLocaleString() + " RPM", "sensor-row");
    if (!temperatures.length && !fans.length)
      empty(
        box,
        "Датчики недоступны: проверьте lm-sensors и поддержку оборудования.",
      );
    // Preserve the original selection: temp1, otherwise the first tempN.
    // Named CPU sensors are only a fallback when no legacy tempN exists.
    const legacyTemperatures = temperatures.filter((x) =>
      /^temp\d+$/.test(x.name),
    );
    const main =
      legacyTemperatures.find((x) => x.name === "temp1") ||
      legacyTemperatures[0] ||
      temperatures.find((x) =>
        /^(Package id 0|Tctl|CPU Temperature)$/i.test(x.name),
      ) ||
      temperatures[0];
    const fan =
      fans.find((x) => /^(CPU Fan Speed|fan1)$/i.test(x.name)) || fans[0];
    text("temp", main ? main.value.toFixed(1) + " °C" : "—");
    $("temp").title = main
      ? "Датчик: " + main.name
      : "Температурный датчик не найден";
    text("fan", fan ? fan.value.toLocaleString() : "—");
    text("power", powers.length ? powers[0].toFixed(1) + " W" : "—");
  }
  function disks(output) {
    const box = $("disks");
    box.replaceChildren();
    for (const line of (output || "").split("\n").slice(1)) {
      const parts = line.trim().split(/\s+/);
      if (parts.length < 6 || !/^\d+%$/.test(parts[4])) continue;
      const value = row(
        box,
        parts[0],
        parts[4],
        "disk-row",
        parts.slice(5).join(" "),
      );
      const percent = parseInt(parts[4], 10);
      if (percent >= 95) value.classList.add("bad");
      else if (percent >= 85) value.classList.add("warn");
    }
    if (!box.children.length) empty(box, "Информация о дисках недоступна.");
  }
  function system(info) {
    const box = $("system");
    box.replaceChildren();
    [
      ["OS", info.os],
      ["Kernel", info.kernel],
      ["Hostname", info.host],
    ].forEach(([key, value]) => {
      const k = document.createElement("div");
      k.className = "k";
      k.textContent = key;
      const v = document.createElement("div");
      v.className = "v";
      v.textContent = value;
      box.append(k, v);
    });
  }

  async function loadStatic() {
    if (staticInfo) return staticInfo;
    const [host, os, kernel] = await Promise.all([
      sh("hostname"),
      sh("sed -n 's/^PRETTY_NAME=//p' /etc/os-release | tr -d '\"'"),
      sh("uname -r"),
    ]);
    staticInfo = { host, os, kernel };
    return staticInfo;
  }
  async function update() {
    if (updating || stopped || document.hidden) return;
    clearTimeout(timer);
    updating = true;
    try {
      const [
        info,
        stat,
        memory,
        load,
        uptime,
        sensorOutput,
        diskOutput,
        network,
      ] = await Promise.all([
        loadStatic(),
        sh("head -n 1 /proc/stat"),
        sh("cat /proc/meminfo"),
        sh("cat /proc/loadavg"),
        sh("cat /proc/uptime"),
        // Keep the server's sensor locale and stdout even on a partial sensors failure.
        spawn(["bash", "-lc", "sensors 2>/dev/null || true"], {
          err: "message",
        }).catch(() => ""),
        sh("df -P -x tmpfs -x devtmpfs -x overlay 2>/dev/null").catch(() => ""),
        // Aggregate interfaces except loopback. Virtual interfaces may count the same traffic twice.
        sh(
          "awk -F '[: ]+' '/:/{if ($2 != \"lo\") {rx += $3; tx += $11}} END{printf \"%.0f %.0f\\n\",rx,tx}' /proc/net/dev",
        ),
      ]);
      const numbers = stat.trim().split(/\s+/).slice(1, 9).map(Number);
      if (numbers.length < 4 || !numbers.every(Number.isFinite))
        throw new Error("Не удалось прочитать статистику CPU.");
      // Fields 9 and 10 (guest, guest_nice) are already included in user/nice.
      const total = numbers.reduce((a, b) => a + b, 0),
        idle = numbers[3] + (numbers[4] || 0);
      const memoryValues = {};
      for (const line of memory.split("\n")) {
        const match = line.match(/^(\w+):\s+(\d+)\s+kB/);
        if (match) memoryValues[match[1]] = Number(match[2]) * 1024;
      }
      const totalRam = memoryValues.MemTotal;
      const available =
        memoryValues.MemAvailable ?? (memoryValues.MemFree || 0);
      if (!Number.isFinite(totalRam) || totalRam <= 0)
        throw new Error("Не удалось прочитать статистику памяти.");
      const used = Math.max(0, totalRam - available),
        ramPercent = pct((used / totalRam) * 100);
      const loads = load.trim().split(/\s+/).slice(0, 3).map(Number);
      const up = parseFloat(uptime),
        net = network.trim().split(/\s+/).map(Number);
      if (
        loads.length !== 3 ||
        !loads.every(Number.isFinite) ||
        !Number.isFinite(up) ||
        net.length !== 2 ||
        !net.every(Number.isFinite)
      ) {
        throw new Error("Получены неполные данные мониторинга.");
      }
      text("hostname", info.host);
      text("os", info.os);
      text("kernel", info.kernel);
      system(info);
      text(
        "uptime",
        Math.floor(up / 86400) +
          "d " +
          Math.floor((up % 86400) / 3600) +
          "h " +
          Math.floor((up % 3600) / 60) +
          "m",
      );
      ["l1", "l5", "l15"].forEach((id, i) => text(id, loads[i].toFixed(2)));
      text("load", loads[0].toFixed(2));
      $("load").title =
        "1 / 5 / 15 мин: " + loads.map((v) => v.toFixed(2)).join(" / ");
      text("ram", fmtBytes(used));
      text(
        "ramDetail",
        fmtBytes(used) +
          " / " +
          fmtBytes(totalRam) +
          " · " +
          ramPercent.toFixed(1) +
          "% used · " +
          fmtBytes(available) +
          " available",
      );
      $("ramBar").style.width = ramPercent + "%";
      push("ram", ramPercent);
      if (lastCpu && total > lastCpu.total && idle >= lastCpu.idle) {
        const cpu = pct(
          100 * (1 - (idle - lastCpu.idle) / (total - lastCpu.total)),
        );
        text("cpu", cpu.toFixed(1));
        gauge(cpu);
        push("cpu", cpu);
      } else {
        text("cpu", "—");
      }
      lastCpu = { total, idle };
      const now = performance.now();
      if (
        lastNet &&
        now > lastNet.time &&
        net[0] >= lastNet.rx &&
        net[1] >= lastNet.tx
      ) {
        const seconds = (now - lastNet.time) / 1000;
        push("rx", (net[0] - lastNet.rx) / seconds);
        push("tx", (net[1] - lastNet.tx) / seconds);
      }
      lastNet = { rx: net[0], tx: net[1], time: now };
      sensors(sensorOutput);
      disks(diskOutput);
      renderCharts();
      text("updated", new Date().toLocaleTimeString());
      connection("ONLINE");
    } catch (error) {
      lastCpu = null;
      lastNet = null;
      connection(
        "ERROR",
        "Обновление не удалось. Показаны последние полученные данные; они могут быть устаревшими. Повторим автоматически. " +
          (error.message || "Проверьте соединение с Cockpit."),
      );
    } finally {
      updating = false;
      if (!stopped && !document.hidden) timer = setTimeout(update, INTERVAL);
    }
  }

  function fanControls() {
    const enabled = confirmedMode === "manual" && !fanBusy;
    $("fanMode").disabled = fanBusy;
    $("fanControl").classList.toggle("fan-disabled", !enabled);
    $("fanSlider").disabled = !enabled;
    document.querySelectorAll("[data-fan-preset]").forEach((button) => {
      button.disabled = !enabled;
      button.setAttribute(
        "aria-pressed",
        String(
          confirmedMode === "manual" &&
            Number(button.dataset.fanPreset) === confirmedSpeed,
        ),
      );
    });
    $("fanControl").setAttribute("aria-busy", String(fanBusy));
  }
  function feedback(message, error = false) {
    text("fanFeedback", message);
    $("fanFeedback").classList.toggle("error", error);
  }
  async function fanCommand(command, nextMode, nextSpeed = confirmedSpeed) {
    if (fanBusy) return;
    if (
      command[0] === "speed" &&
      (!Number.isInteger(nextSpeed) || nextSpeed < 20 || nextSpeed > 100)
    )
      return;
    fanBusy = true;
    fanControls();
    feedback("Применяем настройку…");
    try {
      await spawn(["sudo", "-n", API, ...command], { err: "message" });
      confirmedMode = nextMode;
      confirmedSpeed = nextSpeed;
      feedback(
        nextMode === "auto"
          ? "Команда автоматического режима выполнена."
          : command[0] === "speed"
            ? "Команда скорости " + nextSpeed + "% выполнена."
            : "Команда ручного режима выполнена.",
      );
    } catch (error) {
      feedback(
        "Настройка не подтверждена. Проверьте fan-control-api.sh и разрешение sudo без пароля. " +
          (error.message || ""),
        true,
      );
    } finally {
      fanBusy = false;
      $("fanMode").value = confirmedMode;
      $("fanSlider").value = confirmedSpeed;
      text("fanPercent", confirmedSpeed + "%");
      fanControls();
    }
  }

  function start() {
    // Do not send fan commands or assume the real hardware mode at page load.
    fanControls();
    renderCharts();
    $("fanMode").addEventListener("change", (event) => {
      const mode = event.target.value;
      if (mode === "auto" || mode === "manual") fanCommand([mode], mode);
    });
    $("fanSlider").addEventListener("input", (event) =>
      text("fanPercent", event.target.value + "%"),
    );
    $("fanSlider").addEventListener("change", (event) => {
      if (confirmedMode !== "manual") return;
      const value = Number(event.target.value);
      fanCommand(["speed", String(value)], "manual", value);
    });
    document.querySelectorAll("[data-fan-preset]").forEach((button) =>
      button.addEventListener("click", () => {
        if (confirmedMode !== "manual") return;
        const value = Number(button.dataset.fanPreset);
        fanCommand(["speed", String(value)], "manual", value);
      }),
    );
    if (typeof cockpit === "undefined" || typeof cockpit.spawn !== "function") {
      connection(
        "UNAVAILABLE",
        "Откройте монитор через Cockpit. При открытии HTML как обычного файла реальные данные и управление вентилятором недоступны.",
      );
      $("fanMode").disabled = true;
      feedback("Управление доступно только через Cockpit.");
      return;
    }
    update();
    document.addEventListener("visibilitychange", () => {
      clearTimeout(timer);
      if (!document.hidden) {
        lastCpu = null;
        lastNet = null;
        update();
      }
    });
    const redraw = () => {
      if (resizeFrame) cancelAnimationFrame(resizeFrame);
      resizeFrame = requestAnimationFrame(renderCharts);
    };
    if (typeof ResizeObserver !== "undefined") {
      const observer = new ResizeObserver(redraw);
      ["cpuChart", "ramChart", "netChart"].forEach((id) =>
        observer.observe($(id)),
      );
      window.addEventListener("pagehide", () => observer.disconnect(), {
        once: true,
      });
    } else window.addEventListener("resize", redraw);
    window.addEventListener(
      "pagehide",
      () => {
        stopped = true;
        clearTimeout(timer);
      },
      { once: true },
    );
    window.addEventListener("pageshow", (event) => {
      if (event.persisted) {
        stopped = false;
        update();
      }
    });
  }
  if (document.readyState === "loading")
    document.addEventListener("DOMContentLoaded", start, { once: true });
  else start();
})();
