#!/usr/bin/env python3

import json
import os
import subprocess
import psutil
import time
import re
import shlex
import threading

from flask import Flask, jsonify, request


app = Flask(__name__)

# One lifecycle operation per configured screen, including concurrent clients.
_operation_locks = {}
_locks_guard = threading.Lock()

def operation_lock(screen):
    with _locks_guard:
        return _operation_locks.setdefault(screen, threading.Lock())

CONFIG_PATH = "/usr/share/cockpit/alexterminal/config.json"

ANSI_ESCAPE = re.compile(
    r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])'
)


def clean_ansi(text):
    """Удаляет ANSI-коды цвета терминала."""
    return ANSI_ESCAPE.sub('', text)


LOG_INITIAL_BYTES = 1_000_000   # сколько хвоста отдавать при первом открытии
LOG_CHUNK_MAX = 500_000         # максимум новых данных за один запрос


def pick_log_path(service):
    """Тот же приоритет источников, что был раньше."""
    screen = service.get("screen_name")
    live = f"/tmp/alex_{screen}.log" if screen else None

    if live and os.path.exists(live) and os.path.getsize(live) > 0:
        return live

    if service.get("type") == "minecraft":
        p = os.path.join(service.get("working_dir", ""), "logs", "latest.log")
        if os.path.exists(p):
            return p

    lp = service.get("log_path")
    if service.get("type") == "website" and lp and os.path.exists(lp):
        return lp

    return None


def decode_safe(raw):
    """Декодирует, не обрезая многобайтовый символ на границе чанка.
    Возвращает (текст, сколько байт реально использовано)."""
    for cut in range(4):
        end = len(raw) - cut
        try:
            return raw[:end].decode("utf-8"), end
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", errors="replace"), len(raw)


def read_log_chunk(path, offset, ino):
    st = os.stat(path)
    size = st.st_size

    # Новый файл (перезапуск/ротация) или первый запрос — читаем хвост
    reset = offset is None or offset < 0 or ino != st.st_ino or offset > size

    with open(path, "rb") as f:
        if reset:
            start = max(0, size - LOG_INITIAL_BYTES)
            f.seek(start)
            raw = f.read(size - start)

            skip = 0
            if start > 0:
                # выкидываем оборванный первый символ/строку
                nl = raw.find(b"\n")
                if nl != -1:
                    skip = nl + 1
                    raw = raw[skip:]
        else:
            start = offset
            skip = 0
            f.seek(start)
            raw = f.read(min(size - offset, LOG_CHUNK_MAX))

    text, used = decode_safe(raw)
    text = clean_ansi(text).replace("\r\n", "\n")

    return {
        "log": text,
        "offset": start + skip + used,
        "ino": st.st_ino,
        "reset": reset,
    }   

def load_config():
    if not os.path.exists(CONFIG_PATH):
        return []

    try:
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            return json.load(f).get("services", [])
    except Exception as e:
        print(f"Error loading config: {e}")
        return []


def get_service_by_id(service_id):
    """
    Возвращает сервис ТОЛЬКО из config.json по id.

    ВАЖНО:
    Никогда не доверяем полям сервиса (start_command, working_dir и т.д.),
    пришедшим напрямую из тела запроса — иначе это произвольное
    выполнение команд. Все действия должны идти через эту функцию.
    """
    services = load_config()
    return next(
        (s for s in services if s.get("id") == service_id),
        None
    )


def run_logged(cmd, **kwargs):
    """
    Обёртка над subprocess.run, которая ВСЕГДА логирует
    неуспешный результат (в т.ч. stderr), вместо того чтобы
    тихо проглатывать ошибки через DEVNULL/except.
    """
    try:
        res = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            **kwargs
        )

        if res.returncode != 0:
            print(
                f"[run_logged] command failed; rc={res.returncode}"
            )

        return res

    except Exception as e:
        print(f"[run_logged] execution failed: {type(e).__name__}")
        return None


def get_screen_pid(screen_name):
    """
    Возвращает PID screen-сессии по ТОЧНОМУ совпадению имени.

    ВАЖНО:
    Раньше здесь использовался подстрочный поиск (`screen_name in line`),
    из-за чего "server1" мог случайно матчиться на "server11" и т.п.,
    а также при наличии двух сессий с одинаковым именем возвращалась
    только первая попавшаяся строка. Теперь матчим строго по имени
    после точки в идентификаторе "PID.name".
    """
    if not screen_name:
        return None

    res = run_logged(["screen", "-ls"])

    if res is None:
        return None

    matches = []

    for line in res.stdout.splitlines():
        token = line.strip().split()
        if not token:
            continue

        ident = token[0]

        if '.' not in ident:
            continue

        pid_str, name = ident.split('.', 1)

        if not pid_str.isdigit():
            continue

        if name == screen_name:
            matches.append(int(pid_str))

    if not matches:
        return None

    if len(matches) > 1:
        # Такого быть не должно (см. fix в /api/action start),
        # но если случилось — явно сообщаем в лог, а не молчим,
        # и работаем с самой первой (самой старой) сессией.
        print(
            f"[get_screen_pid] WARNING: found {len(matches)} "
            f"screen sessions named '{screen_name}': {matches}. "
            f"Using the oldest one: {min(matches)}."
        )
        return min(matches)

    return matches[0]


def screen_ident(screen_pid, screen_name):
    """
    Строит однозначный идентификатор сессии "pid.name" для передачи
    в `screen -S`, чтобы никогда не попасть на ошибку screen
    "There are several suitable screens" при совпадении имён.
    """
    return f"{screen_pid}.{screen_name}"


def wait_until_gone(screen_name, timeout=10, interval=0.5):
    """Ждёт, пока screen-сессия реально исчезнет, вместо fixed sleep."""
    waited = 0.0
    while waited < timeout:
        if get_screen_pid(screen_name) is None:
            return True
        time.sleep(interval)
        waited += interval
    return False


# ------------------------------------------------------------------
# Кэш psutil.Process для корректного расчёта CPU%.
#
# ВАЖНО (баг, который был раньше):
# psutil.Process.cpu_percent() считает % CPU как РАЗНИЦУ между
# текущим и предыдущим вызовом ЭТОГО ЖЕ объекта Process. Раньше для
# дочерних процессов каждый раз создавался НОВЫЙ psutil.Process(pid)
# (через proc.children(recursive=True) на каждый опрос), а вызывался
# он сразу с interval=0. Для только что созданного объекта это всегда
# первый вызов — в такой ситуации psutil возвращает "бессмысленный"
# 0.0 (это прямо написано в документации psutil). А тяжёлый процесс
# (обычно Java) внутри screen — это как раз ДОЧЕРНИЙ процесс, а не
# сам screen/bash. В итоге его CPU почти всегда показывался как ~0%,
# и общий CPU занижался, даже если Java реально грузила систему.
#
# Фикс: храним ОДИН И ТОТ ЖЕ объект Process на pid между запросами
# (фронт опрашивает /api/services каждые 2 секунды) — тогда каждый
# следующий вызов cpu_percent(interval=None) честно меряет % CPU за
# прошедший интервал, а не сравнивает объект сам с собой "с нуля".
# ------------------------------------------------------------------

_proc_cache = {}


def _get_cached_process(pid):
    proc = _proc_cache.get(pid)

    if proc is not None:
        try:
            if not proc.is_running():
                del _proc_cache[pid]
                proc = None
        except psutil.Error:
            del _proc_cache[pid]
            proc = None

    if proc is None:
        try:
            proc = psutil.Process(pid)
            # "Прайм": первый вызов всегда даёт мусорное значение —
            # намеренно игнорируем его и сохраняем объект на будущее.
            proc.cpu_percent(interval=None)
            _proc_cache[pid] = proc
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return None

    return proc


def _sweep_dead_cache_entries():
    """Убирает из кэша процессы, которых больше нет — иначе при
    перезапусках сервисов кэш будет расти бесконечно."""
    for pid, proc in list(_proc_cache.items()):
        try:
            if not proc.is_running():
                del _proc_cache[pid]
        except psutil.Error:
            del _proc_cache[pid]


def get_stats(pid):
    """CPU/RAM screen + дочерних процессов."""
    if not pid:
        return {"cpu": 0, "ram": 0}

    try:
        proc = _get_cached_process(pid)

        if proc is None:
            return {"cpu": 0, "ram": 0}

        cpu = proc.cpu_percent(interval=None)
        ram = proc.memory_info().rss

        for child in proc.children(recursive=True):
            try:
                cproc = _get_cached_process(child.pid)

                if cproc is None:
                    continue

                cpu += cproc.cpu_percent(interval=None)
                ram += cproc.memory_info().rss

            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

        return {
            "cpu": round(cpu, 1),
            "ram": ram
        }

    except Exception:
        return {
            "cpu": 0,
            "ram": 0
        }


def get_java_processes(screen_pid):
    """
    Находит Java-процессы внутри дерева конкретного screen.

    ВАЖНО:
    Не трогает другие Java-процессы на сервере.
    """

    result = []

    if not screen_pid:
        return result

    try:
        parent = psutil.Process(screen_pid)

        for proc in parent.children(recursive=True):
            try:
                name = proc.name().lower()
                cmdline = " ".join(proc.cmdline()).lower()

                if (
                    "java" in name
                    or "java" in cmdline
                ):
                    result.append(proc)

            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass

    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass

    return result


def stop_process_tree(screen_pid, screen_name=None):
    """
    Полностью останавливает дерево конкретного screen.

    Сначала:
        SIGTERM

    Затем, если процессы не завершились:
        SIGKILL
    """

    if not screen_pid:
        return True

    try:
        parent = psutil.Process(screen_pid)

        children = parent.children(recursive=True)

    except (psutil.NoSuchProcess, psutil.AccessDenied):
        return True

    # Сначала пытаемся нормально завершить процессы
    for proc in children:
        try:
            proc.terminate()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    # Ждём до 5 секунд
    gone, alive = psutil.wait_procs(
        children,
        timeout=5
    )

    # Если что-то осталось — принудительно убиваем
    for proc in alive:
        try:
            proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    # Убиваем сам screen/bash
    try:
        parent.terminate()
    except (psutil.NoSuchProcess, psutil.AccessDenied):
        pass

    try:
        parent.wait(timeout=3)
    except (psutil.TimeoutExpired, psutil.NoSuchProcess):
        try:
            parent.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    # Дополнительно явно гасим саму screen-сессию по однозначному
    # идентификатору pid.name, если имя известно — иначе psutil.kill
    # мог убить процессы, но screen иногда оставляет "мёртвую" запись.
    if screen_name:
        run_logged([
            "screen", "-S", screen_ident(screen_pid, screen_name),
            "-X", "quit"
        ])

    return True


def graceful_minecraft_stop(screen_name):
    """
    Нормальная остановка Minecraft.

    1. Отправляем stop.
    2. Ждём до 15 секунд.
    3. Если Java не ушла — принудительно завершаем её.
    """

    screen_pid = get_screen_pid(screen_name)

    if not screen_pid:
        return True

    ident = screen_ident(screen_pid, screen_name)

    # Отправляем Minecraft команду stop
    run_logged(["screen", "-S", ident, "-X", "stuff", "stop\n"])

    # Minecraft может сохранять мир.
    # Ждём максимум 15 секунд.
    for _ in range(15):

        time.sleep(1)

        # Проверяем, что PID сессии не сменился (на случай гонки)
        current_pid = get_screen_pid(screen_name)

        # Screen уже исчез — Minecraft полностью остановился
        if current_pid is None:
            return True

        if current_pid != screen_pid:
            print("[stop] Screen PID changed; refusing to stop a replacement session")
            return False

        java_processes = get_java_processes(current_pid)

        # Java больше нет
        if not java_processes:
            # Закрываем оставшийся screen
            run_logged([
                "screen", "-S",
                screen_ident(current_pid, screen_name),
                "-X", "quit"
            ])

            return True

    # ==========================================================
    # Minecraft не завершился самостоятельно.
    # Принудительно убиваем только его дерево.
    # ==========================================================

    print(
        f"Minecraft '{screen_name}' did not stop normally. "
        f"Forcing shutdown."
    )

    screen_pid = get_screen_pid(screen_name)
    java_processes = get_java_processes(screen_pid)

    # Сначала SIGTERM Java
    for proc in java_processes:
        try:
            print(
                f"Stopping Java PID {proc.pid} "
                f"with SIGTERM"
            )
            proc.terminate()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    # Даём Java ещё 3 секунды
    gone, alive = psutil.wait_procs(
        java_processes,
        timeout=3
    )

    # Остались живые — SIGKILL
    for proc in alive:
        try:
            print(
                f"Java PID {proc.pid} did not stop. "
                f"Sending SIGKILL."
            )
            proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass

    # Теперь полностью закрываем screen
    screen_pid = get_screen_pid(screen_name)

    if screen_pid:
        stop_process_tree(screen_pid, screen_name)

    return True


def sweep_orphaned_java(service):
    """
    Сеть безопасности на случай, если java "осиротела" — то есть
    screen/bash над ней уже убиты, а сама java осталась жить и больше
    не находится как потомок screen-сессии (именно это произошло у
    пользователя: SCREEN+bash исчезли, java осталась с CPU 151%).

    Ищем java-процессы СИСТЕМНО (уже не через дерево screen), но
    матчим ТОЛЬКО по working_dir конкретного сервиса — это гарантирует,
    что мы не тронем чужую java на сервере, даже без привязки к PID
    screen-сессии, которой уже может не существовать.
    """

    wdir = service.get("working_dir")

    if not wdir:
        return True

    wdir = os.path.normpath(wdir)
    killed = []

    for proc in psutil.process_iter(["name", "cmdline"]):
        try:
            name = (proc.info.get("name") or "").lower()
            cmdline = " ".join(proc.info.get("cmdline") or []).lower()

            if "java" not in name and "java" not in cmdline:
                continue

            try:
                proc_cwd = os.path.normpath(proc.cwd())
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

            if proc_cwd != wdir:
                continue

            print(
                f"[sweep_orphaned_java] found orphaned java "
                f"PID {proc.pid} in '{wdir}', terminating."
            )

            proc.terminate()
            killed.append(proc)

        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            print(f"[sweep_orphaned_java] skip PID: {e}")
            continue

    if not killed:
        return True

    gone, alive = psutil.wait_procs(killed, timeout=5)

    for proc in alive:
        try:
            print(
                f"[sweep_orphaned_java] PID {proc.pid} did not "
                f"terminate, sending SIGKILL."
            )
            proc.kill()
        except (psutil.NoSuchProcess, psutil.AccessDenied) as e:
            print(
                f"[sweep_orphaned_java] FAILED to kill PID "
                f"{proc.pid}: {e} "
                f"(check that the backend runs as the same user "
                f"that owns this process)."
            )

    _, remaining = psutil.wait_procs(alive, timeout=3)
    return not remaining


def full_stop(service):
    """
    Единая точка остановки сервиса (используется в stop/restart/start),
    чтобы логика не дублировалась и не расходилась между экшенами.
    Возвращает True, если сессия и все связанные процессы гарантированно
    исчезли.
    """
    screen = service.get("screen_name")

    if service.get("type") == "minecraft":
        if not graceful_minecraft_stop(screen):
            return False
    else:
        screen_pid = get_screen_pid(screen)
        if screen_pid:
            stop_process_tree(screen_pid, screen)

    ok = wait_until_gone(screen, timeout=10)

    if not ok:
        # Последняя попытка: сессия всё ещё есть — не даём стартовать
        # поверх неё и плодить дубликаты с одинаковым именем.
        remaining_pid = get_screen_pid(screen)
        print(
            f"[full_stop] WARNING: screen '{screen}' still alive "
            f"as PID {remaining_pid} after stop attempt."
        )

    # Финальная зачистка: даже если screen пропал (ok=True), это НЕ
    # гарантирует, что java внутри него тоже умерла — именно так и
    # получилось в реальном случае (SCREEN+bash исчезли, java осталась
    # жить осиротевшей). Поэтому всегда проверяем отдельно, по
    # working_dir, независимо от состояния screen-дерева.
    if service.get("type") == "minecraft":
        if not sweep_orphaned_java(service):
            ok = False

    return ok


@app.route("/api/services")
def api_services():

    services = load_config()
    results = []

    for s in services:

        screen_name = s.get("screen_name")

        pid = get_screen_pid(screen_name)

        stats = get_stats(pid)
        uptime = None
        if pid:
            try:
                uptime = max(0, time.time() - psutil.Process(pid).create_time())
            except psutil.Error:
                pass

        results.append({
            **s,
            "running": pid is not None,
            "pid": pid,
            "cpu": stats["cpu"],
            "ram": stats["ram"],
            "uptime": uptime
        })

    # Раз в опрос чистим кэш psutil.Process от "мёртвых" записей
    # (сервис остановлен/перезапущен и т.п.) — иначе кэш будет
    # бесконечно расти при частых restart'ах.
    _sweep_dead_cache_entries()

    return jsonify(results)


@app.route("/api/log")
def api_log():

    service_id = request.args.get("id")
    offset = request.args.get("offset", type=int)
    ino = request.args.get("ino", type=int)

    service = get_service_by_id(service_id)

    if not service:
        return jsonify({"log": "Сервис не найден в config.json"}), 404

    path = pick_log_path(service)

    if path:
        try:
            return jsonify(read_log_chunk(path, offset, ino))
        except OSError as e:
            return jsonify({"log": f"Ошибка чтения лога: {e}"})

    # Резервный hardcopy Screen (снимок целиком, без offset)
    screen = service.get("screen_name")

    if screen:
        screen_pid = get_screen_pid(screen)
        tmp = f"/tmp/dump_{screen}.txt"
        ident = screen_ident(screen_pid, screen) if screen_pid else screen

        run_logged(["screen", "-S", ident, "-X", "hardcopy", "-h", tmp])

        if os.path.exists(tmp):
            try:
                with open(tmp, "r", encoding="utf-8", errors="replace") as f:
                    return jsonify({"log": clean_ansi(f.read()[-200000:])})
            except Exception:
                pass

    return jsonify({"log": "Консоль пуста. Нажмите START для запуска."})

@app.route("/api/command", methods=["POST"])
def api_command():

    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"success": False, "message": "Ожидается JSON-объект"}), 400

    service_id = data.get("id")
    cmd = data.get("command")
    if not isinstance(cmd, str) or not cmd.strip() or len(cmd) > 8192 or any(c in cmd for c in ("\n", "\r", "\x00")):
        return jsonify({"success": False, "message": "Нужна одна команда длиной до 8192 символов"}), 400

    # ВАЖНО: screen_name больше не берём из тела запроса напрямую —
    # только из config.json по id, чтобы нельзя было прислать
    # произвольный screen_name и отправить команду в чужую сессию.
    service = get_service_by_id(service_id)

    if not service or not cmd:
        return jsonify({"success": False}), 400

    if service.get("type") == "website":
        return jsonify({"success": False, "message": "Ввод команд для сайта отключён"}), 400

    screen = service.get("screen_name")
    screen_pid = get_screen_pid(screen)

    if not screen_pid:
        return jsonify({
            "success": False,
            "message": "Сервис не запущен"
        }), 400

    ident = screen_ident(screen_pid, screen)

    res = run_logged(["screen", "-S", ident, "-X", "stuff", f"{cmd}\n"])

    if res is None or res.returncode != 0:
        return jsonify({"success": False, "message": "Screen не принял команду"}), 502
    return jsonify({"success": True})


def launch_service(service):
    screen = service["screen_name"]
    wdir = service.get("working_dir", "/tmp")
    live_log = f"/tmp/alex_{screen}.log"
    if os.path.exists(live_log):
        os.remove(live_log)
    # Group cd with the pipeline so failure cannot launch in a wrong directory.
    shell_cmd = f"cd -- {shlex.quote(wdir)} && {{ set -o pipefail; ({service['start_command']}) 2>&1 | tee -- {shlex.quote(live_log)}; }}"
    subprocess.Popen(["screen", "-dmS", screen, "bash", "-c", shell_cmd], shell=False)
    for _ in range(10):
        time.sleep(0.1)
        pid = get_screen_pid(screen)
        if pid is not None:
            return pid
    return None


@app.route("/api/action", methods=["POST"])
def api_action():
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return jsonify({"status": "error", "message": "Ожидается JSON-объект"}), 400
    service = get_service_by_id(data.get("id"))
    action = data.get("action")
    if not service or action not in ("start", "stop", "restart"):
        return jsonify({"status": "error", "message": "Неизвестный сервис или действие"}), 400
    screen = service.get("screen_name")
    if not screen or not re.fullmatch(r"[A-Za-z0-9_.-]+", screen):
        return jsonify({"status": "error", "message": "Некорректный screen_name"}), 400
    # Validate before ANY stop or log deletion, especially for monitoring-only websites.
    if action in ("start", "restart"):
        if not isinstance(service.get("start_command"), str) or not service["start_command"].strip():
            return jsonify({"status": "error", "message": "Запуск недоступен: нет start_command в config.json"}), 400
        if not os.path.isdir(service.get("working_dir", "/tmp")):
            return jsonify({"status": "error", "message": "Рабочая папка не существует"}), 400
    lock = operation_lock(screen)
    if not lock.acquire(blocking=False):
        return jsonify({"status": "error", "message": "Для этого сервиса уже выполняется операция"}), 409
    try:
        pid = get_screen_pid(screen)
        if action == "start" and pid is not None:
            return jsonify({"status": "ok", "action": "start", "pid": pid, "message": "Сервис уже работает"})
        if action in ("stop", "restart"):
            if not full_stop(service):
                return jsonify({"status": "error", "message": "Не удалось полностью остановить сервис; новый запуск отменён"}), 409
            if action == "stop":
                return jsonify({"status": "ok", "action": "stop"})
        # Do not start on top of an orphaned Java process in this service directory.
        if service.get("type") == "minecraft":
            wdir = os.path.normpath(service.get("working_dir", ""))
            for proc in psutil.process_iter(["name", "cmdline"]):
                try:
                    name = (proc.info.get("name") or "").lower()
                    if "java" in name and os.path.normpath(proc.cwd()) == wdir:
                        return jsonify({"status": "error", "message": "В папке ещё работает Java; запуск отменён"}), 409
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
        new_pid = launch_service(service)
        if new_pid is None:
            return jsonify({"status": "error", "message": "Screen-сессия не появилась. Проверьте лог и команду запуска"}), 502
        return jsonify({"status": "ok", "action": action, "pid": new_pid})
    except Exception as exc:
        app.logger.exception("Lifecycle operation failed")
        return jsonify({"status": "error", "message": f"Ошибка {action}: {exc}"}), 500
    finally:
        lock.release()


if __name__ == "__main__":

    app.run(
        host="127.0.0.1",
        port=8765
    )