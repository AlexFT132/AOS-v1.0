"use strict";
const $ = (id) => document.getElementById(id);
const STORE = "alexterminal.v2";
function readSetting(key, fallback) {
  try {
    const v = localStorage.getItem(`${STORE}.${key}`);
    return v === null ? fallback : JSON.parse(v);
  } catch (_) {
    return fallback;
  }
}
function saveSetting(key, value) {
  try {
    localStorage.setItem(`${STORE}.${key}`, JSON.stringify(value));
  } catch (_) {}
}
let services = [],
  currentService = null,
  backendOnline = false,
  servicesBusy = false,
  commandBusy = false;
const actionBusy = new Set(),
  histories = new Map(),
  metrics = new Map(),
  processButtons = new Map();
const favoritesRaw = readSetting("favorites", {});
const favorites =
  favoritesRaw &&
  typeof favoritesRaw === "object" &&
  !Array.isArray(favoritesRaw)
    ? favoritesRaw
    : {};
const savedService = readSetting("service", null);
const savedFilter = readSetting("filter", "all");
const filters = ["all", "error", "warn", "important"];
let filter = filters.includes(savedFilter) ? savedFilter : "all";
let query = readSetting("search", "");
if (typeof query !== "string") query = "";
const scrollState = { pinned: readSetting("pinned", true) !== false };
const MAX_LINES = 10000,
  POLL_MS = 500;
const logState = {
  serviceId: null,
  offset: null,
  ino: null,
  nodes: [],
  tail: null,
  snapshot: null,
  busy: false,
  generation: 0,
};
function notify(message, error = false) {
  $("noticeText").textContent = message;
  $("notice").classList.toggle("error", error);
  $("notice").hidden = false;
}
async function apiRequest(method, endpoint, data = null) {
  if (typeof cockpit === "undefined")
    throw new Error(
      "Открой терминал через Cockpit. В обычном браузере системное подключение недоступно.",
    );
  // HTTP code is separated from the JSON body; no shell interpolation.
  const args = [
    "curl",
    "--unix-socket",
    "/run/alexterminal/api.sock",
    "--silent",
    "--show-error",
    "--connect-timeout",
    "3",
    "--max-time",
    endpoint === "/api/action" ? "90" : "12",
    "--request",
    method,
    "--write-out",
    "\n%{http_code}",
    `http://localhost${endpoint}`,
  ];
  if (data !== null)
    args.push(
      "--header",
      "Content-Type: application/json",
      "--data-binary",
      "@-",
    );
  let output;
  try {
    const proc = cockpit.spawn(args, { superuser: "require" });
    proc.input(data === null ? "" : JSON.stringify(data));
    output = await proc;
  } catch (e) {
    throw new Error(`Нет ответа от backend: ${e.message || String(e)}`);
  }
  const split = output.lastIndexOf("\n"),
    status = Number(output.slice(split + 1));
  let body;
  try {
    body = JSON.parse(output.slice(0, split));
  } catch (_) {
    throw new Error(`Некорректный ответ API (HTTP ${status || "?"})`);
  }
  if (
    status < 200 ||
    status >= 300 ||
    body?.success === false ||
    body?.status === "error"
  )
    throw new Error(body?.message || `Ошибка API: HTTP ${status}`);
  return body;
}
function history(id) {
  if (!histories.has(id)) histories.set(id, { list: [], pos: null, draft: "" });
  return histories.get(id);
}
function saveDraft() {
  if (currentService) {
    const h = history(currentService.id);
    h.draft = $("commandInput").value;
    h.pos = null;
  }
}
function rememberCommand(id, cmd) {
  const h = history(id);
  if (h.list.at(-1) !== cmd) h.list.push(cmd);
  if (h.list.length > 30) h.list.shift();
  h.pos = null;
  h.draft = "";
}
function navigateHistory(direction) {
  if (!currentService) return;
  const h = history(currentService.id),
    input = $("commandInput");
  if (!h.list.length) return;
  if (direction < 0) {
    if (h.pos === null) {
      h.draft = input.value;
      h.pos = h.list.length - 1;
    } else h.pos = Math.max(0, h.pos - 1);
    input.value = h.list[h.pos];
  } else {
    if (h.pos === null) return;
    if (h.pos < h.list.length - 1) input.value = h.list[++h.pos];
    else {
      h.pos = null;
      input.value = h.draft;
    }
  }
  input.setSelectionRange(input.value.length, input.value.length);
}
function uptime(value) {
  if (!Number.isFinite(value)) return "—";
  const n = Math.floor(value),
    d = Math.floor(n / 86400),
    h = Math.floor(n / 3600) % 24,
    m = Math.floor(n / 60) % 60;
  return d ? `${d} д ${h} ч` : h ? `${h} ч ${m} мин` : `${m} мин ${n % 60} с`;
}
function ram(value) {
  return Number.isFinite(value) ? `${(value / 1048576).toFixed(1)} MiB` : "—";
}
function cpu(value) {
  return Number.isFinite(value) ? `${value.toFixed(1)}%` : "—";
}
function updateControls() {
  const s = currentService,
    busy = s && actionBusy.has(s.id),
    canCommand =
      backendOnline &&
      s?.running &&
      s.type !== "website" &&
      !busy &&
      !commandBusy;
  $("btnStart").disabled =
    !backendOnline || !s || busy || s.running || !s.start_command;
  $("btnStop").disabled = !backendOnline || !s || busy || !s.running;
  $("btnRestart").disabled =
    !backendOnline || !s || busy || !s.running || !s.start_command;
  $("btnFolder").disabled = !s?.working_dir;
  $("commandInput").disabled = !canCommand;
  $("btnSend").disabled = !canCommand;
  $("btnFavorite").disabled = !s || s.type === "website";
  $("commandInput").placeholder = !s
    ? "Выбери запущенный сервис…"
    : s.type === "website"
      ? "Ввод команд для сайта отключён"
      : !backendOnline
        ? "Нет соединения с backend"
        : busy
          ? "Выполняется операция…"
          : !s.running
            ? "Сервис остановлен"
            : "Введите команду…";
  for (const id of ["btnCopyLog", "btnDownloadLog", "btnClearLog"])
    $(id).disabled = !s;
  document
    .querySelectorAll(".favorite-command")
    .forEach((b) => (b.disabled = !canCommand));
}
function updateUI() {
  const s = currentService;
  $("curName").textContent = s?.name || "Выбери сервис";
  $("curPid").textContent = s?.pid ? `PID ${s.pid}` : "PID —";
  $("curUptime").textContent = `Время работы ${uptime(s?.uptime)}`;
  const status = $("curStatus");
  status.textContent = !s
    ? "Не выбран"
    : !backendOnline
      ? "Нет связи"
      : actionBusy.has(s.id)
        ? "Операция…"
        : s.running
          ? "Работает"
          : "Остановлен";
  status.className = `status-badge ${backendOnline && s?.running ? "running" : "stopped"}`;
  $("statCpu").textContent = s && backendOnline ? cpu(s.cpu) : "—";
  $("statRam").textContent = s && backendOnline ? ram(s.ram) : "—";
  updateControls();
  drawMetrics();
}
// A compact rail on desktop, a horizontal service strip on mobile.
// Reuse the v2 storage namespace so existing preferences and favorites survive.
let sidebarPreference = readSetting("sidebarCollapsed", null);
let sidebarAnimation = null;
function applySidebarState(animate = false) {
  const sidebar = $("sidebar");
  // Measure the current animated height before cancelling an interrupted fold.
  const previousHeight = sidebar.getBoundingClientRect().height;
  if (sidebarAnimation) {
    sidebarAnimation.cancel();
    sidebarAnimation = null;
  }
  const collapsed =
    sidebarPreference === null
      ? true
      : sidebarPreference === true;
  document
    .querySelector(".terminal-layout")
    .classList.toggle("sidebar-collapsed", collapsed);
  const toggle = $("btnToggleSidebar");
  toggle.setAttribute("aria-expanded", String(!collapsed));
  toggle.title = collapsed
    ? "Развернуть панель сервисов"
    : "Свернуть панель сервисов";
  toggle.querySelector(".sr-only").textContent = toggle.title;
  toggle.setAttribute("aria-label", toggle.title);
  // Hidden favorites must not remain keyboard-focusable in the compact rail.
  $("groupFavorites").inert = false; // Favorites live in Management, outside the sidebar.
  // The service buttons remain available even when the sidebar is collapsed.
  $("groupServices").open = true;
  // Desktop uses an interpolated CSS grid track. Mobile changes to a horizontal
  // rail; animate its measured height instead of jumping between flex layouts.
  if (animate && matchMedia("(max-width:700px)").matches &&
      !matchMedia("(prefers-reduced-motion: reduce)").matches &&
      typeof sidebar.animate === "function") {
    const nextHeight = sidebar.getBoundingClientRect().height;
    if (Math.abs(previousHeight - nextHeight) > 1) {
      const animation = sidebar.animate(
        [{ height: previousHeight + "px", overflow: "hidden" },
         { height: nextHeight + "px", overflow: "hidden" }],
        { duration: 280, easing: "cubic-bezier(.22,.68,0,1)" }
      );
      sidebarAnimation = animation;
      animation.finished.then(() => {
        if (sidebarAnimation === animation) sidebarAnimation = null;
      }).catch(() => {});
    }
  }
}
function renderSidebar() {
  const container = $("processList"),
    ids = new Set(services.map((s) => s.id));
  if (services.length && !processButtons.size) container.replaceChildren();
  for (const [id, b] of processButtons)
    if (!ids.has(id)) {
      b.remove();
      processButtons.delete(id);
    }
  for (const s of services) {
    let btn = processButtons.get(s.id);
    if (!btn) {
      btn = document.createElement("button");
      btn.className = "process";
      const dot = document.createElement("span"),
        content = document.createElement("span"),
        name = document.createElement("span"),
        meta = document.createElement("span");
      dot.className = "process-dot";
      dot.setAttribute("aria-hidden", "true");
      content.className = "process-content";
      name.className = "process-name";
      meta.className = "process-meta";
      content.append(name, meta);
      const code = document.createElement("span");
      code.className = "process-code";
      code.setAttribute("aria-hidden", "true");
      btn.append(dot, code, content);
      btn.addEventListener("click", () => selectService(s.id));
      processButtons.set(s.id, btn);
      container.append(btn);
    }
    const active = currentService?.id === s.id;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-pressed", String(active));
    btn.querySelector(".process-dot").className =
      `process-dot ${backendOnline && s.running ? "online" : ""}`;
    btn.querySelector(".process-name").textContent = s.name;
    // Keep the first two characters of the configured service name, not its index.
    btn.querySelector(".process-code").textContent =
      Array.from(String(s.name ?? s.id ?? "").trim()).slice(0, 2).join("");
    const stateLabel = !backendOnline
      ? "Нет связи"
      : s.running
        ? "Работает"
        : "Остановлен";
    btn.title = `${s.name} — ${stateLabel}`;
    btn.setAttribute("aria-label", btn.title);
    btn.querySelector(".process-meta").textContent = !backendOnline
      ? "Нет связи"
      : s.running
        ? `Работает · ${uptime(s.uptime)} · ${cpu(s.cpu)} · ${ram(s.ram)}`
        : "Остановлен";
  }
  if (!services.length) container.textContent = "Нет сервисов в конфигурации.";
  $("serviceCount").textContent = String(services.length);
}
function selectService(id) {
  const s = services.find((s) => s.id === id);
  if (!s || currentService?.id === id) return;
  saveDraft();
  currentService = s;
  saveSetting("service", id);
  resetLogView(id);
  const h = history(id);
  h.pos = null;
  $("commandInput").value = h.draft;
  renderSidebar();
  renderFavorites();
  updateUI();
  fetchLog();
  $("groupControls").open = false;
}
async function loadServices() {
  if (servicesBusy) return;
  servicesBusy = true;
  try {
    const data = await apiRequest("GET", "/api/services");
    if (!Array.isArray(data))
      throw new Error("API вернул неверный список сервисов");
    services = data;
    backendOnline = true;
    const now = Date.now();
    for (const s of services) {
      if (!metrics.has(s.id)) metrics.set(s.id, []);
      const points = metrics.get(s.id);
      points.push({
        t: now,
        cpu: Number.isFinite(s.cpu) ? s.cpu : null,
        ram: Number.isFinite(s.ram) ? s.ram / 1048576 : null,
        pid: s.pid,
      });
      while (points.length && points[0].t < now - 120000) points.shift();
    }
    if (currentService) {
      const next = services.find((s) => s.id === currentService.id);
      if (!next) {
        saveDraft();
        currentService = null;
        resetLogView(null);
        $("commandInput").value = "";
        renderFavorites();
      } else currentService = next;
    }
    renderSidebar();
    if (
      !currentService &&
      savedService &&
      services.some((s) => s.id === savedService)
    )
      selectService(savedService);
    updateUI();
  } catch (e) {
    const wasOnline = backendOnline;
    backendOnline = false;
    renderSidebar();
    updateUI();
    if (wasOnline || !$("noticeText").textContent) notify(e.message, true);
  } finally {
    servicesBusy = false;
  }
}
async function servicesLoop() {
  await loadServices();
  setTimeout(servicesLoop, 2000);
}
function levelClass(text) {
  if (
    /\b(error|fatal|exception|failed|failure|critical|traceback|segfault|denied|refused)\b|ошибка|сбой/i.test(
      text,
    )
  )
    return "error";
  if (/\b(warn|warning|deprecated|timeout)\b|предупреждение/i.test(text))
    return "warn";
  return "normal";
}
function matches(entry) {
  return (
    (filter === "all" ||
      (filter === "important" && entry.level !== "normal") ||
      entry.level === filter) &&
    (!query ||
      entry.text.toLocaleLowerCase().includes(query.toLocaleLowerCase()))
  );
}
function paint(entry) {
  entry.level = levelClass(entry.text);
  entry.el.className = `line ${entry.level}`;
  entry.el.hidden = !matches(entry);
  entry.el.replaceChildren();
  if (!query) {
    entry.el.textContent = entry.text;
    return;
  }
  const lower = entry.text.toLocaleLowerCase(),
    term = query.toLocaleLowerCase();
  let from = 0,
    at;
  while ((at = lower.indexOf(term, from)) !== -1) {
    entry.el.append(document.createTextNode(entry.text.slice(from, at)));
    const mark = document.createElement("mark");
    mark.textContent = entry.text.slice(at, at + query.length);
    entry.el.append(mark);
    from = at + query.length;
  }
  entry.el.append(document.createTextNode(entry.text.slice(from)));
}
function logSummary() {
  const shown = logState.nodes.reduce((n, e) => n + (!e.el.hidden ? 1 : 0), 0);
  $("logEmpty").hidden = shown > 0;
  $("emptyTitle").textContent = !currentService
    ? "Твой сервер — под контролем"
    : logState.nodes.length
      ? "Совпадений нет"
      : "Пока нет строк";
  $("emptyText").textContent = !currentService
    ? "Выбери сервис в панели сервисов, чтобы открыть консоль."
    : logState.nodes.length
      ? "Измени поисковый запрос или уровень логов."
      : "Ожидаем вывод сервиса. Очистка экрана не удаляет серверный лог.";
}
function scrollBottom() {
  if (scrollState.pinned) $("log").scrollTop = $("log").scrollHeight;
}
function clearLogView() {
  $("log").replaceChildren();
  logState.nodes = [];
  logState.tail = null;
  logSummary();
}
function resetLogView(id) {
  logState.generation++;
  logState.serviceId = id;
  logState.offset = null;
  logState.ino = null;
  logState.snapshot = null;
  clearLogView();
}
function tailLines(text, n) {
  const arr = text.split("\n");
  return arr.length > n ? arr.slice(-n).join("\n") : text;
}
function appendLog(text, reset) {
  if (reset) clearLogView();
  if (!text) {
    logSummary();
    return;
  }
  if (reset) text = tailLines(text, MAX_LINES);
  const parts = text.split("\n"),
    fragment = document.createDocumentFragment();
  for (let i = 0; i < parts.length; i++) {
    const last = i === parts.length - 1,
      piece = parts[i];
    if (last && piece === "") break;
    const nl = last ? "" : "\n";
    if (i === 0 && logState.tail) {
      const e = logState.tail;
      e.text += piece + nl;
      paint(e);
      if (nl) logState.tail = null;
      continue;
    }
    const e = {
      el: document.createElement("span"),
      text: piece + nl,
      level: "normal",
    };
    paint(e);
    fragment.append(e.el);
    logState.nodes.push(e);
    if (!nl) logState.tail = e;
  }
  $("log").append(fragment);
  while (logState.nodes.length > MAX_LINES) {
    const e = logState.nodes.shift();
    e.el.remove();
    if (logState.tail === e) logState.tail = null;
  }
  logSummary();
  requestAnimationFrame(scrollBottom);
}
async function fetchLog() {
  if (!currentService || logState.busy || !backendOnline) return;
  const id = currentService.id;
  if (logState.serviceId !== id) resetLogView(id);
  const generation = logState.generation;
  logState.busy = true;
  try {
    let url = `/api/log?id=${encodeURIComponent(id)}`;
    if (logState.offset !== null && logState.ino !== null)
      url += `&offset=${logState.offset}&ino=${logState.ino}`;
    const res = await apiRequest("GET", url);
    if (currentService?.id !== id || generation !== logState.generation) return;
    if (!res || typeof res.log !== "string")
      throw new Error("Некорректный ответ логов");
    if (typeof res.offset === "number") {
      logState.offset = res.offset;
      logState.ino = res.ino;
      logState.snapshot = null;
      appendLog(res.log, res.reset);
    } else {
      logState.offset = null;
      logState.ino = null;
      if (res.log !== logState.snapshot) {
        logState.snapshot = res.log;
        appendLog(res.log, true);
      }
    }
  } catch (e) {
    if (currentService?.id === id)
      notify(`Не удалось прочитать лог: ${e.message}`, true);
  } finally {
    logState.busy = false;
  }
}
async function logLoop() {
  await fetchLog();
  setTimeout(logLoop, POLL_MS);
}
async function doAction(action) {
  const s = currentService;
  if (!s || actionBusy.has(s.id)) return;
  actionBusy.add(s.id);
  updateUI();
  try {
    const res = await apiRequest("POST", "/api/action", { id: s.id, action });
    notify(
      res.message ||
        `${s.name}: ${action === "start" ? "запущен" : action === "stop" ? "остановлен" : "перезапущен"}.`,
    );
    await loadServices();
    await fetchLog();
  } catch (e) {
    notify(`${s.name}: ${e.message}`, true);
  } finally {
    actionBusy.delete(s.id);
    updateUI();
  }
}
async function sendCommand(event) {
  event.preventDefault();
  const s = currentService,
    input = $("commandInput"),
    cmd = input.value;
  if (!s || input.disabled || !cmd.trim() || commandBusy) return;
  if (/[\r\n\0]/.test(cmd)) {
    notify("Отправляй одну команду за раз.", true);
    return;
  }
  commandBusy = true;
  updateControls();
  try {
    await apiRequest("POST", "/api/command", { id: s.id, command: cmd });
    rememberCommand(s.id, cmd);
    if (currentService?.id === s.id) {
      input.value = "";
    }
    notify(`${s.name}: команда отправлена.`);
    setTimeout(fetchLog, 300);
  } catch (e) {
    notify(e.message, true);
  } finally {
    commandBusy = false;
    updateControls();
    if (currentService?.id === s.id && !input.disabled) input.focus();
  }
}
function favoriteCommands() {
  const list = favorites[currentService?.id];
  return Array.isArray(list)
    ? list.filter((x) => typeof x === "string").slice(0, 20)
    : [];
}
function renderFavorites() {
  const list = $("favoriteList");
  list.replaceChildren();
  const items = favoriteCommands();
  if (!currentService || !items.length) {
    const p = document.createElement("p");
    p.className = "hint";
    p.textContent = !currentService
      ? "Выбери сервис."
      : currentService.type === "website"
        ? "Для сайтов ввод команд отключён."
        : "Введи команду и нажми ☆, чтобы сохранить.";
    list.append(p);
    return;
  }
  for (const cmd of items) {
    const row = document.createElement("div"),
      b = document.createElement("button"),
      del = document.createElement("button");
    row.className = "favorite-row";
    b.className = "favorite-command";
    b.textContent = cmd;
    b.title = cmd;
    b.addEventListener("click", () => {
      if ($("commandInput").disabled) return;
      $("commandInput").value = cmd;
      saveDraft();
      $("commandInput").focus();
    });
    del.className = "favorite-delete";
    del.textContent = "×";
    del.setAttribute("aria-label", `Удалить из избранного: ${cmd}`);
    del.addEventListener("click", () => {
      favorites[currentService.id] = favoriteCommands().filter(
        (x) => x !== cmd,
      );
      saveSetting("favorites", favorites);
      renderFavorites();
      updateControls();
    });
    row.append(b, del);
    list.append(row);
  }
  updateControls();
}
function addFavorite() {
  if (!currentService || currentService.type === "website") return;
  const cmd = $("commandInput").value.trim();
  if (!cmd) {
    notify("Сначала введи команду в строку ввода.");
    return;
  }
  const list = favoriteCommands();
  if (list.includes(cmd)) {
    notify("Эта команда уже сохранена.");
    return;
  }
  if (list.length >= 20) {
    notify("Лимит: 20 избранных команд на сервис.", true);
    return;
  }
  favorites[currentService.id] = [...list, cmd];
  saveSetting("favorites", favorites);
  renderFavorites();
  notify("Команда сохранена. Нажатие на неё только заполняет строку ввода.");
}
function visibleLog() {
  return logState.nodes
    .filter((e) => !e.el.hidden)
    .map((e) => e.text)
    .join("");
}
function downloadLog() {
  if (!currentService) return;
  const blob = new Blob([visibleLog()], { type: "text/plain;charset=utf-8" }),
    url = URL.createObjectURL(blob),
    a = document.createElement("a");
  a.href = url;
  a.download = `${currentService.id.replace(/[^a-zA-Z0-9_-]/g, "_")}-${new Date().toISOString().replace(/[:.]/g, "-")}.txt`;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
  notify("Показанные строки скачаны в TXT.");
}
async function copyLog() {
  const text = visibleLog();
  if (!text) {
    notify("Нет показанных строк для копирования.");
    return;
  }
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
    } else throw new Error();
    notify("Показанные строки скопированы.");
  } catch (_) {
    const t = document.createElement("textarea");
    t.value = text;
    t.setAttribute("aria-label", "Логи для копирования");
    t.className = "clipboard-fallback";
    document.body.append(t);
    t.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch (_) {}
    t.remove();
    notify(
      ok
        ? "Показанные строки скопированы."
        : "Браузер запретил копирование. Используй кнопку «Скачать».",
      !ok,
    );
  }
}
// Independent zero-based CPU (%) and RAM (MiB) scales. CPU may exceed 100%.
// Only observed values are plotted; gaps and PID changes break the line.
function drawMetrics() {
  const points = currentService ? metrics.get(currentService.id) || [] : [];
  for (const [key, id, color, unit] of [
    ["cpu", "cpuChart", "#86b7ff", "%"],
    ["ram", "ramChart", "#c2a7ef", "MiB"],
  ]) {
    const canvas = $(id),
      ctx = canvas.getContext("2d"),
      r = canvas.getBoundingClientRect(),
      dpr = window.devicePixelRatio || 1;
    if (!ctx || !r.width) continue;
    canvas.width = Math.round(r.width * dpr);
    canvas.height = Math.round(r.height * dpr);
    ctx.scale(dpr, dpr);
    const width = r.width,
      height = r.height;
    ctx.clearRect(0, 0, width, height);
    const valid = points.filter((p) => Number.isFinite(p[key]));
    const max = valid.length ? Math.max(...valid.map((p) => p[key])) : 0,
      ceiling = Math.max(
        key === "cpu" ? 100 : 64,
        Math.ceil(max / (key === "cpu" ? 50 : 64)) * (key === "cpu" ? 50 : 64),
      );
    $(key + "Range").textContent = valid.length
      ? `Шкала 0–${ceiling} ${unit}`
      : "Нет измерений";
    canvas.setAttribute(
      "aria-label",
      valid.length
        ? `${key.toUpperCase()}: ${valid.at(-1)[key].toFixed(1)} ${unit}. ${valid.length} измерений за последние 2 минуты. Шкала от 0 до ${ceiling} ${unit}.`
        : "Пока нет измерений",
    );
    ctx.strokeStyle = "#344052";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(1, height - 3);
    ctx.lineTo(width - 1, height - 3);
    ctx.moveTo(1, 3);
    ctx.lineTo(width - 1, 3);
    ctx.stroke();
    if (valid.length < 2) continue;
    const now = Date.now(),
      x = (p) => 4 + ((p.t - (now - 120000)) / 120000) * (width - 8),
      y = (p) => height - 4 - (p[key] / ceiling) * (height - 8);
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    let prev = null;
    for (const p of points) {
      if (!Number.isFinite(p[key])) {
        prev = null;
        continue;
      }
      if (prev && p.t - prev.t < 8000 && p.pid === prev.pid)
        ctx.lineTo(x(p), y(p));
      else ctx.moveTo(x(p), y(p));
      prev = p;
    }
    ctx.stroke();
    for (const p of valid) {
      ctx.beginPath();
      ctx.arc(x(p), y(p), 1.7, 0, Math.PI * 2);
      ctx.fill();
    }
  }
}
document.addEventListener("DOMContentLoaded", () => {
  const narrow = matchMedia("(max-width:700px)");
  const adaptPanels = () => {
    $("groupFavorites").open = !narrow.matches;
    $("groupControls").open = false;
    applySidebarState();
  };
  adaptPanels();
  narrow.addEventListener("change", adaptPanels);
  $("btnToggleSidebar").addEventListener("click", () => {
    sidebarPreference = !document
      .querySelector(".terminal-layout")
      .classList.contains("sidebar-collapsed");
    saveSetting("sidebarCollapsed", sidebarPreference);
    applySidebarState(true);
  });
  document.addEventListener("click", (event) => {
    if (!$("groupControls").contains(event.target))
      $("groupControls").open = false;
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && $("groupControls").open) {
      $("groupControls").open = false;
      $("groupControls").querySelector("summary").focus();
    }
  });
  $("logFilter").value = filter;
  $("logSearch").value = query;
  $("chkAutoScroll").checked = scrollState.pinned;
  for (const [id, action] of [
    ["btnStart", "start"],
    ["btnStop", "stop"],
    ["btnRestart", "restart"],
  ])
    $(id).addEventListener("click", () => doAction(action));
  $("dismissNotice").addEventListener(
    "click",
    () => ($("notice").hidden = true),
  );
  $("btnFolder").addEventListener("click", () => {
    if (currentService?.working_dir && typeof cockpit !== "undefined")
      cockpit.jump(
        `/explorer#open=${encodeURIComponent(currentService.working_dir)}`,
      );
  });
  $("btnClearLog").addEventListener("click", clearLogView);
  $("btnCopyLog").addEventListener("click", copyLog);
  $("btnDownloadLog").addEventListener("click", downloadLog);
  $("btnFavorite").addEventListener("click", addFavorite);
  $("commandForm").addEventListener("submit", sendCommand);
  $("commandInput").addEventListener("input", saveDraft);
  $("commandInput").addEventListener("keydown", (e) => {
    if (e.key === "ArrowUp" || e.key === "ArrowDown") {
      e.preventDefault();
      navigateHistory(e.key === "ArrowUp" ? -1 : 1);
    }
  });
  $("chkAutoScroll").addEventListener("change", () => {
    scrollState.pinned = $("chkAutoScroll").checked;
    saveSetting("pinned", scrollState.pinned);
    scrollBottom();
  });
  let searchTimer;
  const applyFilter = () => {
    for (const e of logState.nodes) paint(e);
    logSummary();
    scrollBottom();
    saveSetting("filter", filter);
    saveSetting("search", query);
  };
  $("logSearch").addEventListener("input", () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => {
      query = $("logSearch").value;
      applyFilter();
    }, 120);
  });
  $("logFilter").addEventListener("change", () => {
    filter = $("logFilter").value;
    applyFilter();
  });
  new ResizeObserver(drawMetrics).observe($("cpuChart"));
  new ResizeObserver(drawMetrics).observe($("ramChart"));
  new ResizeObserver(scrollBottom).observe($("log"));
  renderFavorites();
  logSummary();
  updateUI();
  servicesLoop();
  logLoop();
});

function toggleDesignGraph(key){
 const panel=$("graphDrawer");
 if(key==="all"){
  const opening=panel.hidden;panel.hidden=!opening;
  for(const kind of ["cpu","ram"])$("metric-"+kind).hidden=!opening;
  const button=document.querySelector('[data-graph="all"]');button.textContent=opening?'∨':'<';button.setAttribute('aria-expanded',String(opening));button.setAttribute('aria-label',opening?'Скрыть графики':'Показать графики');
 }else{
  const el=$("metric-"+key),opening=el.hidden;el.hidden=!opening;
  const button=document.querySelector('[data-graph="'+key+'"]');button.textContent=opening?'∨':'<';button.setAttribute('aria-expanded',String(opening));button.setAttribute('aria-label',opening?'Скрыть графики':'Показать графики');
  panel.hidden=$("metric-cpu").hidden&&$("metric-ram").hidden;
 }
 const visible=[...panel.querySelectorAll('.metric')].filter(el=>!el.hidden).length;
 panel.classList.toggle('one-graph',visible===1);
 requestAnimationFrame(()=>{drawMetrics();scrollBottom();});
}
document.addEventListener('DOMContentLoaded',()=>{
 document.querySelectorAll('[data-graph]').forEach(button=>button.addEventListener('click',()=>toggleDesignGraph(button.dataset.graph)));
 });
